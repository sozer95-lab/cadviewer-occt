plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.serdar.cadviewer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.serdar.cadviewer"
        minSdk = 26              // WebView'de modern JS (ES module) ve CAD Goruntuleyici icin guvenli alt sinir
        targetSdk = 35
        versionCode = 6
        versionName = "1.5.0"    // CAD Goruntuleyici arayuzu Malzeme Kutuphanesi ile gorsel olarak tutarli hale getirildi

        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += "-DCADVIEWER_HAS_OCCT=1"
            }
        }
    }

    // ONEMLI: CMakeLists.txt bu OCCT .so dosyalarini "IMPORTED SHARED target"
    // olarak tanimlayip derleme zamaninda BAGLAR (linker bulur), ama bu TEK
    // BASINA .so dosyalarinin APK icine KONULMASINI SAGLAMAZ. Android Gradle
    // Plugin, CMake IMPORTED kutuphanelerini OTOMATIK OLARAK jniLibs'e
    // kopyalamaz - bu yuzden onceden derlenmis OCCT .so dosyalarinin
    // bulundugu klasoru ACIKCA bir jniLibs kaynagi olarak eklemek GEREKIR;
    // aksi halde derleme basarili olur ama cihazda calisirken
    // "library ... not found" / "cannot locate symbol" hatasi alinir.
    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("src/main/cpp/third_party/occt/arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Malzeme Kutuphanesi (MaterialLibraryActivity) icin
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    // CAD Goruntuleyici (com.cadviewer.*) duz Activity/GLSurfaceView kullanir,
    // ek bir Gradle bagimliligi gerektirmez (JNI + Android SDK yeterli).
}
