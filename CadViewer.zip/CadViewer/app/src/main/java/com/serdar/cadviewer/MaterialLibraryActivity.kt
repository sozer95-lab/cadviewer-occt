package com.serdar.cadviewer

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

/**
 * Uygulama tek bir WebView'den ibarettir; butun is mantigi assets icindeki
 * web uygulamasindadir (malzeme kutuphanesi: arama, elle kimya girip
 * eslestirme, kendi malzemeni ekleme).
 *
 * Hicbir ag izni yoktur; internet baglantisi kurulmaz. Kutuphane verisi
 * (kullanicinin ekledigi malzemeler) yalnizca cihazin localStorage'inda
 * saklanir.
 *
 * ONEMLI — sayfa NASIL YUKLENIR: "file://" KULLANILMAZ. Android WebView'de
 * file:// sayfasindaki JS, ayni klasordeki kardes dosyalara bile
 * fetch()/import() ile erisemez (setAllowFileAccessFromFileURLs varsayilani
 * API 16 ve ustu icin FALSE'dur). Bu da ES module import'larini (app.js'in
 * malzeme.js/eslesme.js'i import etmesi) engeller.
 *
 * Cozum: androidx.webkit.WebViewAssetLoader ile assets/ klasorunu sanal bir
 * https:// kaynagindan (https://appassets.androidplatform.net/) servis
 * etmek. Bu, gercek bir https:// origin'dir; ES module'lerin CORS/MIME
 * kisitlamalarina takilmadan yuklenmesini saglar.
 */
class MaterialLibraryActivity : AppCompatActivity() {

    private lateinit var web: WebView

    companion object {
        const val APP_ORIGIN = "https://appassets.androidplatform.net"
        const val APP_URL = "$APP_ORIGIN/assets/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true      // localStorage: eklenen malzemeler burada durur
            loadWithOverviewMode = false
            useWideViewPort = false
            builtInZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        web.loadUrl(APP_URL)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
