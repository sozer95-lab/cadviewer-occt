package com.serdar.cadviewer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.cadviewer.CadViewerActivity

/**
 * Uygulamanin acilis ekrani (LAUNCHER). Iki bagimsiz alt uygulamaya gecis
 * saglar:
 *  - Malzeme Kutuphanesi (WebView tabanli, MaterialLibraryActivity)
 *  - CAD Goruntuleyici (native OpenGL/JNI tabanli, com.cadviewer.CadViewerActivity)
 *
 * Bu iki alt uygulama BILEREK birbirinden bagimsiz Activity'ler olarak
 * tutulur: biri WebView + dikey duzen, digeri tam ekran + yatay kilitli
 * OpenGL yuzeyi. Ikisini tek bir ekranda birlestirmeye calismak gereksiz
 * karmasiklik ve kararlilik riski katar; bu yuzden her biri kendi
 * bagimsizligini korur, bu ekran sadece aralarinda gecis yapar.
 */
class HomeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val celik = Color.parseColor("#2E4A5E")
        val zemin = Color.parseColor("#EEF1EF")
        val menevis = Color.parseColor("#C97B2E")
        val metinIkincil = Color.parseColor("#5B6570")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(zemin)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(celik)
            setPadding(dp(20), dp(28), dp(20), dp(20))
        }
        header.addView(TextView(this).apply {
            text = "Çözüm Kalite"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "Malzeme kütüphanesi ve CAD görüntüleyici"
            setTextColor(Color.parseColor("#C6D3DA"))
            textSize = 13f
            setPadding(0, dp(2), 0, 0)
        })
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val scroll = ScrollView(this)
        val govde = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        fun kart(baslik: String, aciklama: String, buton: String, renk: Int, aksiyon: () -> Unit) {
            val kart = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(18), dp(18), dp(18))
                setBackgroundColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(16) }
            }
            kart.addView(TextView(this).apply {
                text = baslik; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            })
            kart.addView(TextView(this).apply {
                text = aciklama; textSize = 13f; setTextColor(metinIkincil)
                setPadding(0, dp(6), 0, dp(14))
            })
            kart.addView(Button(this).apply {
                text = buton
                setTextColor(Color.WHITE)
                setBackgroundColor(renk)
                setOnClickListener { aksiyon() }
            })
            govde.addView(kart)
        }

        kart(
            "Malzeme Kütüphanesi",
            "Malzeme ara, elle girilen kimyasal analizle eşleştir, kendi malzemeni ekle.",
            "Aç",
            celik
        ) { startActivity(Intent(this, MaterialLibraryActivity::class.java)) }

        kart(
            "CAD Görüntüleyici",
            "STL/OBJ dosyalarını görüntüle, ölç. STEP/IGES için CAD çekirdeği (OCCT) bu derlemede yok.",
            "Aç",
            menevis
        ) { startActivity(Intent(this, CadViewerActivity::class.java)) }

        scroll.addView(govde)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
