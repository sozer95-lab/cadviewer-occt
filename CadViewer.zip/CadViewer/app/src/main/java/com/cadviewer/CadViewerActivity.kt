package com.cadviewer
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.net.Uri
import android.content.Intent
import org.json.JSONArray
import java.io.File
import java.util.Locale

data class MaterialEntry(val ad: String, val no: String, val sinif: String, val yogunluk: Float) {
    override fun toString(): String = "$ad  (${yogunluk} g/cm\u00b3, $sinif)"
}

// Renk paleti Malzeme Kutuphanesi'nin (assets/index.html :root degiskenleri)
// BIREBIR AYNISI - iki modul GORSEL OLARAK TUTARLI olsun diye.
private object Palet {
    val ZEMIN = Color.parseColor("#EEF1EF")
    val YUZEY = Color.WHITE
    val METIN = Color.parseColor("#1C2126")
    val METIN_IKINCIL = Color.parseColor("#5B6570")
    val CIZGI = Color.parseColor("#D6DAD7")
    val CELIK = Color.parseColor("#2E4A5E")
    val CELIK_KOYU = Color.parseColor("#1F3444")
    val MENEVIS = Color.parseColor("#C97B2E")
    val MENEVIS_KOYU = Color.parseColor("#A9631E")
}

class CadViewerActivity : Activity() {
    private var materials: List<MaterialEntry> = emptyList()
    private var selectedMaterial: MaterialEntry? = null
    private lateinit var weightView: android.widget.TextView
    private lateinit var sizeView: android.widget.TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // Yuvarlak koseli, dolgu renkli, dokunma geri bildirimli (ripple) bir
    // "hap" (pill) arka planı uretir - Malzeme Kutuphanesi'ndeki buton
    // stiliyle AYNI dilde (yuvarlak kose, duz dolgu renk).
    private fun pillDrawable(fill: Int): android.graphics.drawable.Drawable {
        val radius = dp(18).toFloat()
        val shapeDrawable = GradientDrawable().apply { setColor(fill); cornerRadius = radius }
        val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = radius }
        return RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)), shapeDrawable, mask)
    }

    private fun pillButton(text: String, bg: Int, fg: Int = Color.WHITE, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            setTextColor(fg)
            textSize = 13f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(10), dp(18), dp(10))
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            background = pillDrawable(bg)
            stateListAnimator = null
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
        }
    }

    // Butonlar arasi renkli grup ayraci - farkli islev gruplarini (Dosya /
    // Gorunum / Olcum / Malzeme) etiket eklemeden, sadece ince bir cizgiyle
    // gorsel olarak ayirir.
    private fun grupAyraci(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(28)).apply {
            marginStart = dp(4); marginEnd = dp(12); gravity = Gravity.CENTER_VERTICAL
        }
        setBackgroundColor(Palet.CIZGI)
    }

    // Ust bilgi cubugundaki her bir "istatistik" (Olcum / Boyut / Agirlik)
    // icin kucuk-harfli bir etiket + altinda deger gosteren bir sutun uretir.
    // Deger TextView'i geri dondurulur ki update fonksiyonlari onu guncelleyebilsin.
    private fun statChip(etiket: String, container: LinearLayout): android.widget.TextView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(android.widget.TextView(this).apply {
            text = etiket; textSize = 10f; setTextColor(Palet.METIN_IKINCIL)
            typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.05f
        })
        val deger = android.widget.TextView(this).apply {
            text = "\u2014"; textSize = 13f; setTextColor(Palet.METIN); setPadding(0, dp(2), 0, 0)
        }
        col.addView(deger)
        container.addView(col)
        return deger
    }

    // assets/materials.json, Malzeme Kutuphanesi'nin (malzeme.js) 600
    // kaydindan (ad, standart no, sinif, yogunluk g/cm3) turetilmis bir
    // anlik goruntudur - iki modul arasindaki KOPRU verisidir. Kimyasal
    // bilesim burada YOK (agirlik hesabi icin sadece yogunluk gerekiyor).
    private fun loadMaterials(): List<MaterialEntry> {
        return try {
            val text = assets.open("materials.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                MaterialEntry(
                    ad = o.getString("ad"),
                    no = o.optString("no", "\u2014"),
                    sinif = o.optString("sinif", ""),
                    yogunluk = o.getDouble("yogunluk").toFloat()
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun showMaterialPicker() {
        if (materials.isEmpty()) {
            Toast.makeText(this, "Malzeme listesi yuklenemedi", Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(4))
        }
        val search = EditText(this).apply {
            hint = "Malzeme ara\u2026 (\u00f6r. 42CrMo4)"
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Palet.ZEMIN); cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Palet.CIZGI)
            }
        }
        container.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val listView = ListView(this)
        container.addView(listView, LinearLayout.LayoutParams(-1, dp(360)))

        var filtered = materials
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filtered.map { it.toString() })
        listView.adapter = adapter

        val baslik = android.widget.TextView(this).apply {
            text = "Malzeme se\u00e7"
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 16f
            setBackgroundColor(Palet.CELIK)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }

        val dialog = AlertDialog.Builder(this)
            .setCustomTitle(baslik)
            .setView(container)
            .setNegativeButton("\u0130ptal", null)
            .create()

        listView.setOnItemClickListener { _, _, pos, _ ->
            val secilen = filtered[pos]
            selectedMaterial = secilen
            CadNative.nativeSetMaterialDensity(secilen.yogunluk)
            updateWeightDisplay()
            dialog.dismiss()
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s?.toString()?.trim()?.lowercase(Locale.getDefault()) ?: ""
                filtered = if (q.isBlank()) materials else materials.filter {
                    it.ad.lowercase(Locale.getDefault()).contains(q) || it.no.lowercase(Locale.getDefault()).contains(q)
                }
                adapter.clear(); adapter.addAll(filtered.map { it.toString() }); adapter.notifyDataSetChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        dialog.show()
    }

    // Malzeme secilmediyse / model yuklu degilse / format desteklemiyorsa
    // durumu ACIKCA belirtir; sessizce "0 kg" gostermek YANILTICI olurdu.
    private fun updateWeightDisplay() {
        if (!CadNative.nativeHasModel()) { weightView.text = "\u2014"; return }
        val mat = selectedMaterial
        val volumeCm3 = CadNative.nativeVolumeCm3()
        if (volumeCm3 <= 0.0) {
            weightView.text = "desteklenmiyor (DWG/DXF)"
            return
        }
        if (mat == null) {
            weightView.text = "hacim %.2f cm\u00b3 \u2014 malzeme se\u00e7in".format(volumeCm3)
            return
        }
        val weightKg = CadNative.nativeWeightKg()
        val hassasiyet = if (CadNative.nativeVolumeIsExact()) "tam" else "yakla\u015f\u0131k"
        weightView.text = "%.3f kg  (%s, %s)".format(weightKg, mat.ad, hassasiyet)
    }

    // mm -> inch donusum katsayisi (1 mm = 0.0393700787 inch). Boyut
    // gosterimi icin KOTLIN tarafinda uygulanir (native her zaman HAM mm
    // dondurur); mesafe olcumu icin ise AYNI katsayi C++ tarafinda
    // (applyLengthUnit) uygulanir - iki yer de TUTARLI kalsin diye AYNI
    // sabiti kullanirlar.
    private val MM_TO_INCH = 0.0393700787f

    private fun updateSizeDisplay() {
        if (!CadNative.nativeHasModel()) { sizeView.text = "\u2014"; return }
        val s = CadNative.nativeModelSizeMm()
        if (s.size < 3 || (s[0] <= 0f && s[1] <= 0f && s[2] <= 0f)) { sizeView.text = "\u2014"; return }
        val inch = CadNative.nativeLengthUnitIsInch()
        val birim = if (inch) "in" else "mm"
        val k = if (inch) MM_TO_INCH else 1f
        sizeView.text = "%.1f \u00d7 %.1f \u00d7 %.1f %s".format(s[0]*k, s[1]*k, s[2]*k, birim)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        materials = loadMaterials()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palet.ZEMIN)
        }

        // --- Ust baslik cubugu (Malzeme Kutuphanesi'ndeki header ile AYNI celik mavisi) ---
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palet.CELIK)
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        header.addView(android.widget.TextView(this).apply {
            text = "CAD G\u00f6r\u00fcnt\u00fcleyici"
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 17f
        })
        val kernelBilgi = android.widget.TextView(this).apply {
            textSize = 11f; setTextColor(Color.parseColor("#C6D3DA")); setPadding(0, dp(2), 0, 0)
        }
        header.addView(kernelBilgi)
        root.addView(header, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        // --- 3B goruntuleyici yuzeyi (koyu celik zeminle cevrili) ---
        val viewerFrame = FrameLayout(this).apply { setBackgroundColor(Palet.CELIK_KOYU) }
        val surface = CadViewerSurface(this)
        viewerFrame.addView(surface, FrameLayout.LayoutParams(-1, -1))
        val overlayContainer = FrameLayout(this)
        viewerFrame.addView(overlayContainer, FrameLayout.LayoutParams(-1, -1))
        val overlay = android.widget.TextView(this).apply {
            text = ""; textSize = 14f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(Color.argb(210, 41, 60, 75)); cornerRadius = dp(6).toFloat() }
            setPadding(dp(10), dp(6), dp(10), dp(6)); visibility = View.GONE
        }
        overlayContainer.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(viewerFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // --- Bilgi kartı: Olcum | Boyut | Agirlik (uc sutunlu, kart gorunumlu) ---
        val infoKart = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Palet.YUZEY)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        val olcumDeger = statChip("\u00d6L\u00c7\u00dcM", infoKart)
        statChip("BOYUT", infoKart).also { sizeView = it }
        statChip("A\u011eIRLIK", infoKart).also { weightView = it }
        root.addView(infoKart, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(View(this).apply { setBackgroundColor(Palet.CIZGI) }, LinearLayout.LayoutParams(-1, dp(1)))
        olcumDeger.text = "\u2014"

        // --- Arac cubugu: yatay kaydirilabilir, islev grubuna gore renkli hap butonlar ---
        val toolbarScroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Palet.YUZEY)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        toolbarScroll.addView(bar, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Grup 1: Dosya (celik mavisi - en onemli/birincil eylem)
        bar.addView(pillButton("A\u00e7") { CadFilePicker.launch(this) })
        bar.addView(grupAyraci())
        // Grup 2: Gorunum (notr koyu gri - kamera/gorsel ayarlar)
        val gorunumRengi = Palet.METIN_IKINCIL
        bar.addView(pillButton("Fit", gorunumRengi) { CadNative.nativeFit() })
        bar.addView(pillButton("Home", gorunumRengi) { CadNative.nativeHome() })
        bar.addView(pillButton("Tel Kafes", gorunumRengi) {
            CadNative.nativeSetWireframeMode(!CadNative.nativeWireframeMode())
        })
        bar.addView(pillButton("mm/in", gorunumRengi) {
            CadNative.nativeSetLengthUnit(!CadNative.nativeLengthUnitIsInch())
            updateSizeDisplay()
            val label = CadNative.nativeMeasurementLabel()
            if (label.isNotBlank()) olcumDeger.text = label
        })
        bar.addView(grupAyraci())
        // Grup 3: Olcum (meneviş amber - analiz/olcum eylemleri)
        bar.addView(pillButton("Distance", Palet.MENEVIS) {
            CadNative.nativeBeginMeasurement(1); olcumDeger.text = "2 nokta se\u00e7in\u2026"
        })
        bar.addView(pillButton("Angle", Palet.MENEVIS) {
            CadNative.nativeBeginMeasurement(2); olcumDeger.text = "3 nokta se\u00e7in\u2026"
        })
        bar.addView(pillButton("Sil (son)", Palet.MENEVIS_KOYU) {
            olcumDeger.text = if (CadNative.nativeDeleteLastMeasurement())
                "silindi (${CadNative.nativeMeasurementHistoryCount()} kaldı)" else "ge\u00e7mi\u015f bo\u015f"
        })
        bar.addView(pillButton("Temizle", Palet.MENEVIS_KOYU) {
            CadNative.nativeClearMeasurement(); olcumDeger.text = "\u2014"
        })
        bar.addView(grupAyraci())
        // Grup 4: Malzeme + Kesit (koyu celik - ikincil ozel araclar)
        bar.addView(pillButton("Malzeme", Palet.CELIK_KOYU) { showMaterialPicker() })

        // --- Kesit (section) kontrol satırı ---
        var kesitEksen = 2 // varsayilan: Z
        val kesitKontrol = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Palet.YUZEY)
            setPadding(dp(16), dp(8), dp(16), dp(12))
        }
        val eksenBtnler = mutableMapOf<Int, Button>()
        fun eksenVurguGuncelle() {
            eksenBtnler.forEach { (eksen, btn) -> btn.alpha = if (eksen == kesitEksen) 1.0f else 0.4f }
        }
        val kesitSeekBar = android.widget.SeekBar(this).apply {
            max = 200 // 0..200 -> fraction -1f..1f (100 = orta/merkez)
            progress = 100
        }
        for ((etiket, eksen) in listOf("X" to 0, "Y" to 1, "Z" to 2)) {
            val b = pillButton(etiket, Palet.CELIK) {
                kesitEksen = eksen
                eksenVurguGuncelle()
                CadNative.nativeSetSectionPlane(kesitEksen, (kesitSeekBar.progress - 100) / 100f)
            }
            eksenBtnler[eksen] = b
            kesitKontrol.addView(b)
        }
        eksenVurguGuncelle()
        kesitKontrol.addView(kesitSeekBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        kesitSeekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                CadNative.nativeSetSectionPlane(kesitEksen, (progress - 100) / 100f)
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
        bar.addView(pillButton("Kesit", Palet.CELIK_KOYU) {
            val yeniDurum = !CadNative.nativeSectionEnabled()
            CadNative.nativeSetSectionEnabled(yeniDurum)
            kesitKontrol.visibility = if (yeniDurum) View.VISIBLE else View.GONE
            if (yeniDurum) CadNative.nativeSetSectionPlane(kesitEksen, (kesitSeekBar.progress - 100) / 100f)
        })

        root.addView(toolbarScroll, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(kesitKontrol, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        surface.onMeasurementUpdated = { status ->
            val label = CadNative.nativeMeasurementLabel()
            olcumDeger.text = if (label.isNotBlank()) label else status
        }
        surface.onMeasurementLabelFrame = {
            val label = CadNative.nativeMeasurementLabel()
            val pos = CadNative.nativeMeasurementLabelScreen()
            if (label.isNotBlank() && pos.size >= 3 && pos[0] >= 0f && pos[1] >= 0f) {
                overlay.text = label
                overlay.visibility = View.VISIBLE
                overlay.x = pos[0]
                overlay.y = pos[1]
            } else overlay.visibility = View.GONE
        }
        // Kullanicidan gizlenmemesi gereken durum: STEP/IGES icin gercek CAD
        // kernel (OCCT) bu derlemede yok. STL/OBJ formatlari kernel'den
        // bagimsiz calisir; bu yuzden "acilmiyor" izlenimi vermek yerine
        // hangi formatlarin calistigini acikca yaziyoruz.
        kernelBilgi.text = if (CadNative.nativeKernelAvailable())
            "STEP/IGES + STL/OBJ + DWG/DXF destekleniyor"
        else
            "STL/OBJ/DWG/DXF destekleniyor \u2014 STEP/IGES i\u00e7in CAD \u00e7ekirde\u011fi (OCCT) bu derlemede yok"
    }
    @Deprecated("Use Activity Result APIs in the final UI layer")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != CadFilePicker.REQUEST_OPEN_CAD || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
        // ONEMLI: gecici dosya, orijinal dosyanin UZANTISINI da tasimali.
        // Native tarafta format algilama tamamen dosya adinin uzantisina
        // bakarak yapiliyor (bkz. OCCTKernelAdapter::open / MeshFileReader);
        // uzantisiz bir gecici dosya adi VERILIRSE hicbir format ASLA
        // taninmaz. Once secilen URI'nin gercek goruntulenen adini (display
        // name) sorup oradan uzantiyi cikariyoruz; bulunamazsa content
        // resolver'in bildirdigi MIME turunden tahmin ediyoruz.
        val displayName = queryDisplayName(uri)
        val ext = displayName?.substringAfterLast('.', missingDelimiterValue = "")
            ?.lowercase()?.takeIf { it.isNotBlank() }
            ?: extFromMime(contentResolver.getType(uri))
        val tmp = File(cacheDir, "cad_import_${System.currentTimeMillis()}" + if (ext.isNullOrBlank()) "" else ".$ext")
        contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
        val ok = CadNative.nativeOpen(tmp.absolutePath)
        if (!ok) {
            val mesaj = if (ext in setOf("step", "stp", "iges", "igs"))
                "STEP/IGES icin CAD cekirdegi (OCCT) bu derlemede yok"
            else
                "Dosya acilamadi. Desteklenen turler: STEP, STP, IGES, IGS, STL, OBJ, DWG, DXF"
            Toast.makeText(this, mesaj, Toast.LENGTH_LONG).show()
        } else {
            updateWeightDisplay()
            updateSizeDisplay()
            val desteklenmeyen = CadNative.nativeDwgUnsupportedSolidCount()
            if (desteklenmeyen > 0) {
                Toast.makeText(
                    this,
                    "$desteklenmeyen adet 3D kati (ACIS, tel kafes verisi de yok) goruntulenemedi",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (_: Exception) { null }
    }

    private fun extFromMime(mime: String?): String? = when (mime) {
        "model/stl", "application/sla", "application/vnd.ms-pki.stl" -> "stl"
        "model/obj", "text/plain+obj" -> "obj"
        "application/step", "model/step" -> "step"
        "application/iges", "model/iges" -> "iges"
        "image/vnd.dwg", "application/dwg" -> "dwg"
        "image/vnd.dxf", "application/dxf" -> "dxf"
        else -> null
    }
}
