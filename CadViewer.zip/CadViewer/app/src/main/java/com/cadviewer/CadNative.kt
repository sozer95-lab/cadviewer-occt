package com.cadviewer

object CadNative {
    init { System.loadLibrary("cadviewer") }
    external fun nativeInit()
    external fun nativeResize(width: Int, height: Int)
    external fun nativeDraw()
    external fun nativeOrbit(dx: Float, dy: Float)
    external fun nativeZoom(delta: Float)
    external fun nativeOpen(path: String): Boolean
    external fun nativeKernelAvailable(): Boolean
    external fun nativeClose()
    external fun nativeFit()
    external fun nativeHome()
    external fun nativeBeginMeasurement(type: Int)
    external fun nativeClearMeasurement()
    external fun nativePick(x: Float, y: Float): Boolean
    external fun nativeMeasurementPointCount(): Int
    external fun nativeMeasurementRequiredPoints(): Int
    external fun nativeMeasurementValue(): Double
    external fun nativeMeasurementUnit(): String
    external fun nativeMeasurementLabel(): String
    external fun nativeMeasurementLabelScreen(): FloatArray
    external fun nativeMeasurementHistoryCount(): Int
    external fun nativeDeleteLastMeasurement(): Boolean

    // Agirlik hesaplama (malzeme kutuphanesi entegrasyonu)
    external fun nativeSetMaterialDensity(densityGCm3: Float)
    external fun nativeMaterialDensity(): Float
    external fun nativeVolumeCm3(): Double
    external fun nativeWeightKg(): Double
    external fun nativeVolumeIsExact(): Boolean
    external fun nativeDwgUnsupportedSolidCount(): Int
    external fun nativeHasModel(): Boolean

    // Kesit (section/clipping plane) gorunumu
    external fun nativeSetSectionEnabled(enabled: Boolean)
    external fun nativeSectionEnabled(): Boolean
    external fun nativeSetSectionPlane(axis: Int, fraction: Float)

    // Uzunluk birimi (mm/inch) - sadece mesafe olcumunu etkiler, aci etkilenmez
    external fun nativeSetLengthUnit(inch: Boolean)
    external fun nativeLengthUnitIsInch(): Boolean

    // Parca boyutu (X x Y x Z), her zaman mm cinsinden doner
    external fun nativeModelSizeMm(): FloatArray

    // Tel kafes / dolu yuzey gorunumu (ana ucgen mesh icin)
    external fun nativeSetWireframeMode(enabled: Boolean)
    external fun nativeWireframeMode(): Boolean
}
