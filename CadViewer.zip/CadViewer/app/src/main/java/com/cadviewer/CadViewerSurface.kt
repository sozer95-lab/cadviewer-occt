package com.cadviewer

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CadViewerSurface(context: Context) : GLSurfaceView(context) {
    private var lastX = 0f
    private var lastY = 0f
    var onMeasurementUpdated: ((String) -> Unit)? = null
    var onMeasurementLabelFrame: (() -> Unit)? = null

    init {
        setEGLContextClientVersion(3)
        setRenderer(object : Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                CadNative.nativeInit()
            }
            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                CadNative.nativeResize(width, height)
            }
            override fun onDrawFrame(gl: GL10?) {
                CadNative.nativeDraw()
                post { onMeasurementLabelFrame?.invoke() }
            }
        })
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                // A tap (without a meaningful drag) is forwarded to the native picking pipeline.
                val dx = event.x - lastX
                val dy = event.y - lastY
                if (dx * dx + dy * dy < 64f) queueEvent {
                    if (CadNative.nativePick(event.x, event.y)) {
                        val v = CadNative.nativeMeasurementValue()
                        val u = CadNative.nativeMeasurementUnit()
                        val count = CadNative.nativeMeasurementPointCount()
                        val required = CadNative.nativeMeasurementRequiredPoints()
                        val text = if (u.isBlank()) "Measurement: point $count/$required selected"
                                   else "Measurement: %.3f %s — tap again for new measurement".format(v, u)
                        post { onMeasurementUpdated?.invoke(text) }
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                val dy = event.y - lastY
                lastX = event.x
                lastY = event.y
                queueEvent { CadNative.nativeOrbit(dx, dy) }
                return true
            }
        }
        return true
    }
}
