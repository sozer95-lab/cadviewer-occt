package com.cadviewer

import android.app.Activity
import android.content.Intent

object CadFilePicker {
    const val REQUEST_OPEN_CAD = 4107
    fun launch(activity: Activity) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/step", "application/iges", "model/step", "model/iges",
                "model/stl", "application/sla", "model/obj",
                "image/vnd.dwg", "application/dwg", "image/vnd.dxf", "application/dxf",
                "*/*"
            ))
        }
        activity.startActivityForResult(intent, REQUEST_OPEN_CAD)
    }
}
