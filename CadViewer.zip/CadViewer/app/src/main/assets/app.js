import { MALZEMELER, SINIF, ELEMENT_AD, ara, aralikYaz } from './malzeme.js';
import { esles } from './eslesme.js';

/* ---------- Özel malzemeler (localStorage) ---------- */
const OZEL_ANAHTAR = 'ck_ozel_malzemeler_v1';

function ozelMalzemeleriYukle() {
  try {
    const ham = localStorage.getItem(OZEL_ANAHTAR);
    return ham ? JSON.parse(ham) : [];
  } catch { return []; }
}
function ozelMalzemeleriKaydet(liste) {
  localStorage.setItem(OZEL_ANAHTAR, JSON.stringify(liste));
}
let ozelMalzemeler = ozelMalzemeleriYukle();

function tumHavuz() {
  return MALZEMELER.concat(ozelMalzemeler);
}

/* ---------- Sekme geçişi ---------- */
const sekmeler = ['ara', 'esle', 'ekle'];
function sekmeGoster(ad) {
  for (const s of sekmeler) {
    document.getElementById('panel-' + s).style.display = s === ad ? '' : 'none';
    document.getElementById('tab-' + s).classList.toggle('aktif', s === ad);
  }
  document.getElementById('detay').style.display = 'none';
  window.scrollTo(0, 0);
}
for (const s of sekmeler) {
  document.getElementById('tab-' + s).addEventListener('click', () => sekmeGoster(s));
}

/* ================= ARAMA ================= */
const aramaKutu = document.getElementById('aramaKutu');
const aramaListe = document.getElementById('aramaListe');
const aramaSayac = document.getElementById('aramaSayac');
let aktifSinifFiltre = null;

function sinifSeciciKur() {
  const kapsayici = document.getElementById('sinifFiltre');
  const tumu = document.createElement('button');
  tumu.className = 'cip aktif';
  tumu.textContent = 'Tümü';
  tumu.addEventListener('click', () => { aktifSinifFiltre = null; sinifCipYenile(); aramaCiz(); });
  kapsayici.appendChild(tumu);
  for (const [kod, ad] of Object.entries(SINIF)) {
    const b = document.createElement('button');
    b.className = 'cip';
    b.textContent = ad;
    b.dataset.kod = kod;
    b.addEventListener('click', () => { aktifSinifFiltre = kod; sinifCipYenile(); aramaCiz(); });
    kapsayici.appendChild(b);
  }
}
function sinifCipYenile() {
  const kapsayici = document.getElementById('sinifFiltre');
  [...kapsayici.children].forEach((el) => {
    el.classList.toggle('aktif', (aktifSinifFiltre == null && el.textContent === 'Tümü') || el.dataset.kod === aktifSinifFiltre);
  });
}

function aramaCiz() {
  const sorgu = aramaKutu.value.trim();
  let sonuc = ara(sorgu, ozelMalzemeler);
  if (aktifSinifFiltre) sonuc = sonuc.filter((m) => m.sinif === aktifSinifFiltre);
  sonuc = sonuc.slice(0, 150);
  aramaSayac.textContent = sonuc.length + (sonuc.length === 150 ? '+' : '') + ' malzeme';
  aramaListe.innerHTML = '';
  if (!sonuc.length) {
    const bos = document.createElement('div');
    bos.className = 'bosDurum';
    bos.textContent = 'Eşleşen malzeme yok.';
    aramaListe.appendChild(bos);
    return;
  }
  for (const m of sonuc) {
    const satir = document.createElement('div');
    satir.className = 'satirKapsayici';
    const dolu = Object.keys(m.kimya || {}).length > 0;
    const secili = karsilastirmaIcerir(m);
    satir.innerHTML = `
      <button class="karsilastirKutu ${secili ? 'karsilastirKutuSecili' : ''}" aria-label="Karşılaştırmaya ekle" title="Karşılaştırmaya ekle">${secili ? '✓' : '+'}</button>
      <button class="satir">
        <div class="satirUst">
          <span class="satirAd">${kacir(m.en)}</span>
          <span class="satirNo">${kacir(m.no || '—')}</span>
        </div>
        <div class="satirAlt">
          <span>${kacir(SINIF[m.sinif] || m.sinif)}</span>
          ${dolu ? '<span class="etiket etiketDolu">kimya var</span>' : '<span class="etiket">kimya yok</span>'}
        </div>
      </button>`;
    satir.querySelector('.satir').addEventListener('click', () => detayGoster(m));
    satir.querySelector('.karsilastirKutu').addEventListener('click', (e) => {
      e.stopPropagation();
      karsilastirmaDegistir(m);
    });
    aramaListe.appendChild(satir);
  }
}
aramaKutu.addEventListener('input', aramaCiz);

/* ---------- Malzeme karşılaştırma (2-3 malzeme yan yana) ---------- */
const KARSILASTIRMA_LIMIT = 3;
let karsilastirmaListesi = [];

function karsilastirmaAnahtar(m) {
  return m.en + '|' + (m.no || '');
}
function karsilastirmaIcerir(m) {
  const anahtar = karsilastirmaAnahtar(m);
  return karsilastirmaListesi.some((x) => karsilastirmaAnahtar(x) === anahtar);
}
function karsilastirmaDegistir(m) {
  const anahtar = karsilastirmaAnahtar(m);
  const idx = karsilastirmaListesi.findIndex((x) => karsilastirmaAnahtar(x) === anahtar);
  if (idx >= 0) {
    karsilastirmaListesi.splice(idx, 1);
  } else {
    if (karsilastirmaListesi.length >= KARSILASTIRMA_LIMIT) {
      karsilastirmaCubuguGoster(`En fazla ${KARSILASTIRMA_LIMIT} malzeme karşılaştırabilirsiniz.`);
      return;
    }
    karsilastirmaListesi.push(m);
  }
  aramaCiz();
  karsilastirmaCubuguGuncelle();
}
function karsilastirmaCubuguGuncelle() {
  const cubuk = document.getElementById('karsilastirCubuk');
  const sayacEl = document.getElementById('karsilastirSayac');
  const btn = document.getElementById('karsilastirGosterBtn');
  if (karsilastirmaListesi.length === 0) {
    cubuk.style.display = 'none';
    return;
  }
  cubuk.style.display = 'flex';
  sayacEl.textContent = `${karsilastirmaListesi.length} malzeme seçili`;
  btn.disabled = karsilastirmaListesi.length < 2;
}
function karsilastirmaCubuguGoster(mesaj) {
  const sayacEl = document.getElementById('karsilastirSayac');
  const eski = sayacEl.textContent;
  sayacEl.textContent = mesaj;
  clearTimeout(karsilastirmaCubuguGoster._t);
  karsilastirmaCubuguGoster._t = setTimeout(() => { karsilastirmaCubuguGuncelle(); }, 1800);
}
document.getElementById('karsilastirTemizle').addEventListener('click', () => {
  karsilastirmaListesi = [];
  aramaCiz();
  karsilastirmaCubuguGuncelle();
});
document.getElementById('karsilastirGosterBtn').addEventListener('click', () => {
  if (karsilastirmaListesi.length < 2) return;
  karsilastirmaGoster(karsilastirmaListesi);
});

function karsilastirmaGoster(malzemeler) {
  const panel = document.getElementById('detay');
  // Tum secili malzemelerin kimyasindaki elementlerin BIRLESIMI (union),
  // element sembolune gore alfabetik siralanir.
  const elementler = [...new Set(malzemeler.flatMap((m) => Object.keys(m.kimya || {})))].sort();
  const sutun = (icerikFn) => malzemeler.map((m) => `<td>${icerikFn(m)}</td>`).join('');
  panel.innerHTML = `
    <div class="detayUst">
      <button id="detayGeri" class="geriBtn">← Geri</button>
    </div>
    <h2 class="detayAd">Karşılaştırma</h2>
    <div class="karsilastirSarici">
      <table class="karsilastirTablo">
        <thead>
          <tr><th>&nbsp;</th>${malzemeler.map((m) => `<th>${kacir(m.en)}</th>`).join('')}</tr>
        </thead>
        <tbody>
          <tr><td class="karsilastirEtiket">Numara</td>${sutun((m) => kacir(m.no || '—'))}</tr>
          <tr><td class="karsilastirEtiket">Sınıf</td>${sutun((m) => kacir(SINIF[m.sinif] || m.sinif))}</tr>
          <tr><td class="karsilastirEtiket">Standart</td>${sutun((m) => kacir(m.std || '—'))}</tr>
          <tr><td class="karsilastirEtiket">AISI/ASTM</td>${sutun((m) => kacir(m.aisi || '—'))}</tr>
          <tr><td class="karsilastirEtiket">Yoğunluk</td>${sutun((m) => m.yog ? m.yog + ' g/cm³' : '—')}</tr>
          ${elementler.map((el) => `
            <tr>
              <td class="karsilastirEtiket">${el}</td>
              ${sutun((m) => m.kimya && m.kimya[el] ? '%' + kacir(aralikYaz(m.kimya[el])) : '<span class="karsilastirYok">—</span>')}
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div class="bolumAciklama" style="margin-top:14px">Kimyasal bileşim aralıkları karşılaştırmalıdır; malzeme seçimi için sertifika değerlerini esas alın.</div>
  `;
  panel.style.display = 'block';
  document.getElementById('detayGeri').addEventListener('click', () => { panel.style.display = 'none'; });
  panel.scrollIntoView({ behavior: 'auto', block: 'start' });
}

/* ---------- Detay paneli ---------- */
function detayGoster(m) {
  const panel = document.getElementById('detay');
  const kimyaSatirlari = Object.entries(m.kimya || {})
    .map(([el, v]) => `
      <div class="kimyaSatir">
        <span class="kimyaEl">${el}</span>
        <span class="kimyaAd">${ELEMENT_AD[el] || ''}</span>
        <span class="kimyaDeger">%${kacir(aralikYaz(v))}</span>
      </div>`).join('');
  panel.innerHTML = `
    <div class="detayUst">
      <button id="detayGeri" class="geriBtn">← Geri</button>
    </div>
    <h2 class="detayAd">${kacir(m.en)}</h2>
    <div class="detayAlt">${kacir(m.no || '—')} · ${kacir(SINIF[m.sinif] || m.sinif)}</div>
    <div class="detayBilgi">
      <div><span class="etiketAnahtar">Standart</span><span>${kacir(m.std || '—')}</span></div>
      <div><span class="etiketAnahtar">AISI/ASTM</span><span>${kacir(m.aisi || '—')}</span></div>
      <div><span class="etiketAnahtar">Eski ad</span><span>${kacir(m.eski || '—')}</span></div>
      <div><span class="etiketAnahtar">Yoğunluk</span><span>${m.yog ? m.yog + ' g/cm³' : '—'}</span></div>
    </div>
    ${kimyaSatirlari
      ? `<div class="kimyaBaslik">Kimyasal bileşim</div><div class="kimyaTablo">${kimyaSatirlari}</div>`
      : `<div class="uyariKutu">Bu malzemenin doğrulanmış bir bileşim aralığı henüz kayıtlı değil.</div>`}
    ${m.mek ? `<div class="notKutu">${kacir(m.mek)}</div>` : ''}
  `;
  panel.style.display = 'block';
  document.getElementById('detayGeri').addEventListener('click', () => { panel.style.display = 'none'; });
  panel.scrollIntoView({ behavior: 'auto', block: 'start' });
}

/* ================= EŞLEŞTİRME ================= */
const eslesElementler = ['C','Si','Mn','P','S','Cr','Ni','Mo','V','Cu','Al','Ti','Nb','N','W','Co'];
const eslesGirdi = {};

function eslesFormKur() {
  const kapsayici = document.getElementById('eslesForm');
  kapsayici.innerHTML = '';
  for (const el of eslesElementler) {
    const satir = document.createElement('label');
    satir.className = 'girdiSatir';
    satir.innerHTML = `<span class="girdiEt">${el}</span>
      <input type="number" step="0.001" inputmode="decimal" placeholder="—" data-el="${el}" class="girdiKutu">
      <span class="girdiYuzde">%</span>`;
    kapsayici.appendChild(satir);
  }
  kapsayici.querySelectorAll('input').forEach((inp) => {
    inp.addEventListener('input', () => { eslesGirdi[inp.dataset.el] = inp.value; });
  });
}

document.getElementById('eslesBtn').addEventListener('click', () => {
  const analiz = {};
  for (const [el, v] of Object.entries(eslesGirdi)) {
    if (v !== '' && v != null) analiz[el] = v;
  }
  const sonucKutu = document.getElementById('eslesSonuc');
  if (!Object.keys(analiz).length) {
    sonucKutu.innerHTML = '<div class="bosDurum">Eşleştirmek için en az bir element yüzdesi girin.</div>';
    return;
  }
  const adaylar = esles(analiz, { ekstra: ozelMalzemeler, adet: 8 });
  if (!adaylar.length) {
    sonucKutu.innerHTML = '<div class="bosDurum">Uyan malzeme bulunamadı.</div>';
    return;
  }
  sonucKutu.innerHTML = adaylar.map((a, i) => {
    const notlar = [];
    if (a.sapan.length) notlar.push('sapan: ' + a.sapan.join(', '));
    if (a.fazla.length) notlar.push('kapsam dışı element: ' + a.fazla.join(', '));
    return `
      <button class="adaySatir ${a.tam ? 'adayTam' : ''}" data-idx="${i}">
        <div class="satirUst">
          <span class="satirAd">${kacir(a.m.en)}</span>
          <span class="${a.tam ? 'rozetTam' : 'rozetYakin'}">${a.tam ? 'tam uyuyor' : 'yakın'}</span>
        </div>
        <div class="satirAlt"><span>${kacir(a.m.no || '—')} · ${kacir(SINIF[a.m.sinif] || a.m.sinif)}</span></div>
        ${notlar.length ? `<div class="adayNot">${kacir(notlar.join(' · '))}</div>` : ''}
      </button>`;
  }).join('');
  sonucKutu.querySelectorAll('.adaySatir').forEach((btn, i) => {
    btn.addEventListener('click', () => detayGoster(adaylar[i].m));
  });
});

document.getElementById('eslesTemizle').addEventListener('click', () => {
  document.querySelectorAll('#eslesForm input').forEach((inp) => { inp.value = ''; });
  for (const k of Object.keys(eslesGirdi)) delete eslesGirdi[k];
  document.getElementById('eslesSonuc').innerHTML = '';
});

/* ================= MALZEME EKLE ================= */
const ekleElementSatirlari = [];

function ekleElementSatiriEkle(el = '', min = '', max = '') {
  const kapsayici = document.getElementById('ekleKimya');
  const satir = document.createElement('div');
  satir.className = 'ekleKimyaSatir';
  satir.innerHTML = `
    <input type="text" placeholder="Element (Cr)" class="ekEl" value="${kacir(el)}">
    <input type="number" step="0.001" placeholder="min" class="ekMin" value="${kacir(min)}">
    <input type="number" step="0.001" placeholder="maks" class="ekMax" value="${kacir(max)}">
    <button type="button" class="ekSil" aria-label="Satırı sil">✕</button>`;
  satir.querySelector('.ekSil').addEventListener('click', () => satir.remove());
  kapsayici.appendChild(satir);
}
document.getElementById('ekleElementBtn').addEventListener('click', () => ekleElementSatiriEkle());

document.getElementById('ekleForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const ad = document.getElementById('ekleAd').value.trim();
  if (!ad) { document.getElementById('ekleAd').focus(); return; }
  const kimya = {};
  document.querySelectorAll('#ekleKimya .ekleKimyaSatir').forEach((satir) => {
    const el = satir.querySelector('.ekEl').value.trim();
    const minV = satir.querySelector('.ekMin').value;
    const maxV = satir.querySelector('.ekMax').value;
    if (!el || (minV === '' && maxV === '')) return;
    kimya[el] = [minV === '' ? null : parseFloat(minV), maxV === '' ? null : parseFloat(maxV)];
  });
  const yeni = {
    sinif: 'OZEL',
    en: ad,
    no: document.getElementById('ekleNo').value.trim() || '—',
    eski: '—',
    aisi: document.getElementById('ekleAisi').value.trim() || '—',
    std: document.getElementById('ekleStandart').value.trim() || '—',
    yog: parseFloat(document.getElementById('ekleYogunluk').value) || 7.85,
    kimya,
    dogrulandi: false,
    mek: document.getElementById('ekleNot').value.trim(),
  };
  ozelMalzemeler.push(yeni);
  ozelMalzemeleriKaydet(ozelMalzemeler);
  document.getElementById('ekleForm').reset();
  document.getElementById('ekleKimya').innerHTML = '';
  ekleElementSatiriEkle();
  ekleBasariGoster();
  ozelListeCiz();
});

function ekleBasariGoster() {
  const uyari = document.getElementById('ekleBasari');
  uyari.style.display = 'block';
  clearTimeout(ekleBasariGoster._t);
  ekleBasariGoster._t = setTimeout(() => { uyari.style.display = 'none'; }, 2200);
}

function ozelListeCiz() {
  const kapsayici = document.getElementById('ozelListe');
  if (!ozelMalzemeler.length) {
    kapsayici.innerHTML = '<div class="bosDurum">Henüz eklediğiniz bir malzeme yok.</div>';
    return;
  }
  kapsayici.innerHTML = ozelMalzemeler.map((m, i) => `
    <div class="ozelSatir">
      <button class="ozelSatirAd" data-idx="${i}">${kacir(m.en)}</button>
      <button class="ozelSil" data-idx="${i}" aria-label="Sil">Sil</button>
    </div>`).join('');
  kapsayici.querySelectorAll('.ozelSatirAd').forEach((btn) => {
    btn.addEventListener('click', () => detayGoster(ozelMalzemeler[+btn.dataset.idx]));
  });
  kapsayici.querySelectorAll('.ozelSil').forEach((btn) => {
    btn.addEventListener('click', () => {
      ozelMalzemeler.splice(+btn.dataset.idx, 1);
      ozelMalzemeleriKaydet(ozelMalzemeler);
      ozelListeCiz();
      aramaCiz();
    });
  });
}

/* ---------- yardımcı ---------- */
function kacir(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* ---------- başlat ---------- */
sinifSeciciKur();
aramaCiz();
eslesFormKur();
ekleElementSatiriEkle();
ozelListeCiz();
karsilastirmaCubuguGuncelle();
document.getElementById('toplamSayac').textContent = tumHavuz().length + ' malzeme kayıtlı';
