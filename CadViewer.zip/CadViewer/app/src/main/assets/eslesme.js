/* eslesme.js — Elle girilen kimyasal analizi malzeme veritabanıyla
 * karşılaştırır. Teyit değildir, aday listesi verir. */
import { MALZEMELER } from './malzeme.js';

/* Kalıntı (artık) element sınırları — bunların ALTINDA kalan bir element
   spekte yoksa görmezden gelinir; ÜSTÜNDE ise aleyhte kanıt sayılır. */
const ARTIK = { Ni:0.30, Cr:0.30, Cu:0.35, Mo:0.10, Sn:0.05, V:0.05 };

function uyarMi(v, aralik) {
  const [a, b] = aralik;
  if (a != null && v < a) return false;
  if (b != null && v > b) return false;
  return true;
}
function sapma(v, aralik) {
  const [a, b] = aralik;
  if (a != null && v < a) return a - v;
  if (b != null && v > b) return v - b;
  return 0;
}

export function esles(analiz, secenek) {
  const o = secenek || {};
  const anahtar = Object.keys(analiz).filter((el) => analiz[el] != null && analiz[el] !== '');
  if (!anahtar.length) return [];
  const tumHavuz = o.ekstra && o.ekstra.length ? MALZEMELER.concat(o.ekstra) : MALZEMELER;
  const havuz = tumHavuz.filter((m) => Object.keys(m.kimya || {}).length > 0);

  const sonuc = havuz.map((m) => {
    const uyan = [], sapan = [], fazla = [], kapsamDisi = [];
    let toplamSapma = 0;

    for (const el of anahtar) {
      const v = parseFloat(analiz[el]);
      if (!isFinite(v)) continue;
      const spek = m.kimya[el];
      if (spek) {
        if (uyarMi(v, spek)) uyan.push(el);
        else { sapan.push(el); toplamSapma += sapma(v, spek) * 20; }
      } else {
        const sinirli = ARTIK[el];
        if (sinirli != null && v <= sinirli) { /* artik element, sessizce gec */ }
        else { fazla.push(el); toplamSapma += 15; }
      }
    }
    for (const el of Object.keys(m.kimya)) {
      if (!(el in analiz) || analiz[el] == null || analiz[el] === '') kapsamDisi.push(el);
    }
    const puan = uyan.length * 10 - toplamSapma - kapsamDisi.length * 2;
    const tam = sapan.length === 0 && fazla.length === 0;
    return { m, puan, tam, uyan, sapan, fazla, kapsamDisi };
  });

  sonuc.sort((a, b) => b.puan - a.puan);
  return sonuc.slice(0, o.adet || 8);
}
