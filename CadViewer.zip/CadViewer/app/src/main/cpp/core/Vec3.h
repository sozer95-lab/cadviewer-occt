#pragma once
#include <cmath>
struct Vec3 { float x{}, y{}, z{}; Vec3 operator+(const Vec3& b)const{return{x+b.x,y+b.y,z+b.z};} Vec3 operator-(const Vec3& b)const{return{x-b.x,y-b.y,z-b.z};} Vec3 operator*(float s)const{return{x*s,y*s,z*s};} };
inline float dot(const Vec3&a,const Vec3&b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline float length(const Vec3&a){return std::sqrt(dot(a,a));}
inline Vec3 cross(const Vec3&a,const Vec3&b){return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x};}
inline Vec3 normalize(const Vec3&a){const float len=length(a); return len>1e-9f ? Vec3{a.x/len,a.y/len,a.z/len} : Vec3{0,0,1};}
