#pragma once
#include <cmath>
struct Mat4 {
    float m[16]{};
    static Mat4 identity(){ Mat4 r{}; r.m[0]=r.m[5]=r.m[10]=r.m[15]=1; return r; }
    static Mat4 perspective(float fovy,float aspect,float n,float f){
        Mat4 r{}; float t=1.0f/std::tan(fovy*0.5f); r.m[0]=t/aspect; r.m[5]=t;
        r.m[10]=(f+n)/(n-f); r.m[11]=-1; r.m[14]=(2*f*n)/(n-f); return r;
    }
};
