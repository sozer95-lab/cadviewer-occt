#include "Picking.h"
#include <cmath>
#include <limits>
static bool hitTri(const Ray&r,const Vec3&a,const Vec3&b,const Vec3&c,float&t){const float e=1e-6f;Vec3 ab=b-a,ac=c-a,p{r.direction.y*ac.z-r.direction.z*ac.y,r.direction.z*ac.x-r.direction.x*ac.z,r.direction.x*ac.y-r.direction.y*ac.x};float det=dot(ab,p);if(std::fabs(det)<e)return false;float inv=1/det;Vec3 s=r.origin-a;float u=dot(s,p)*inv;if(u<0||u>1)return false;Vec3 q{s.y*ab.z-s.z*ab.y,s.z*ab.x-s.x*ab.z,s.x*ab.y-s.y*ab.x};float v=dot(r.direction,q)*inv;if(v<0||u+v>1)return false;t=dot(ac,q)*inv;return t>e;}
PickResult Picker::pick(const Ray&r,const MeshData&m){PickResult o;float best=std::numeric_limits<float>::max();for(auto&t:m.triangles){if(t.a>=m.vertices.size()||t.b>=m.vertices.size()||t.c>=m.vertices.size())continue;float d;if(hitTri(r,m.vertices[t.a].position,m.vertices[t.b].position,m.vertices[t.c].position,d)&&d<best){best=d;o.hit=true;o.distance=d;o.faceId=t.faceId;o.worldPoint=r.origin+r.direction*d;}}return o;}

// Iki dogru (ray + sinirli segment) arasindaki en yakin nokta ciftini bulan
// standart geometri hesabi. `raySeg` ray uzerindeki parametreyi, `segT`
// segment uzerindeki [0,1] parametresini, donus degeri iki nokta arasindaki
// mesafeyi verir.
static float closestDistanceRaySegment(const Ray& r, const Vec3& a, const Vec3& b, Vec3& outWorldPointOnSegment, float& outRayParam) {
    const Vec3 d = r.direction;
    const Vec3 seg = b - a;
    const Vec3 w0 = r.origin - a;
    const float aa = dot(d, d);
    const float bb = dot(d, seg);
    const float cc = dot(seg, seg);
    const float dd = dot(d, w0);
    const float ee = dot(seg, w0);
    const float denom = aa * cc - bb * bb;
    float sc, tc; // sc: ray parametresi, tc: segment parametresi [0,1]
    if (std::fabs(denom) < 1e-9f) {
        // Ray ve segment (yaklasik) paralel - segmentin baslangicini kullan.
        sc = (bb > cc ? dd / bb : ee / cc);
        tc = 0.0f;
    } else {
        sc = (bb * ee - cc * dd) / denom;
        tc = (aa * ee - bb * dd) / denom;
    }
    if (sc < 0.0f) sc = 0.0f; // ray sadece ileri yonde gecerlidir
    if (tc < 0.0f) tc = 0.0f;
    if (tc > 1.0f) tc = 1.0f;
    const Vec3 pointOnRay = r.origin + d * sc;
    const Vec3 pointOnSeg = a + seg * tc;
    outWorldPointOnSegment = pointOnSeg;
    outRayParam = sc;
    return length(pointOnRay - pointOnSeg);
}

PickResult Picker::pickLines(const Ray& r, const std::vector<Vec3>& points, float tolerance) {
    PickResult o;
    float bestDist = tolerance;
    float bestRayParam = std::numeric_limits<float>::max();
    for (size_t i = 0; i + 1 < points.size(); i += 2) {
        Vec3 worldPoint; float rayParam;
        const float dist = closestDistanceRaySegment(r, points[i], points[i + 1], worldPoint, rayParam);
        // Tolerans icinde VE ray boyunca daha once secilen bir noktadan daha
        // YAKINSA (kameraya daha yakin) tercih et - boylece arka plandaki
        // uzak bir cizgi, one gelen bir cizgiyi GOLGELEMEZ.
        if (dist <= bestDist && rayParam < bestRayParam) {
            bestDist = dist;
            bestRayParam = rayParam;
            o.hit = true;
            o.distance = rayParam;
            o.faceId = i / 2;
            o.worldPoint = worldPoint;
        }
    }
    return o;
}
