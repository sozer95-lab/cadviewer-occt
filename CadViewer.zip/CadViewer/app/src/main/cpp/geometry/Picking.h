#pragma once
#include "Ray.h"
#include "Mesh.h"
#include <vector>
struct PickResult { bool hit=false; unsigned long long faceId=0; Vec3 worldPoint{}; float distance=0; };
class Picker {
public:
    static PickResult pick(const Ray&, const MeshData&);
    // DWG/DXF gibi cizgi tabanli (ucgensiz) geometriler icin: ray'e en yakin
    // cizgi segmentini (points, her 2 ardisik nokta bir segment) bulur.
    // `tolerance`, ray ile segment arasindaki en yakin mesafe icin kabul
    // edilebilir ust sinirdir (dunya birimi cinsinden) - bu OLMADAN, ray
    // sahnenin cok uzagindan gecen bir cizgiyi bile "en yakin" olarak
    // secebilir, ki bu kullanic beklentisiyle UYUSMAZ.
    static PickResult pickLines(const Ray&, const std::vector<Vec3>& points, float tolerance);
};
