#pragma once
#include <vector>
#include <cmath>
#include "../core/Vec3.h"
struct MeshVertex { Vec3 position; Vec3 normal; };
struct MeshTriangle { unsigned a{},b{},c{}; unsigned long long faceId{}; };
struct MeshData { std::vector<MeshVertex> vertices; std::vector<MeshTriangle> triangles; };

// Kapali (su gecirmez) bir ucgen agindan, diverjans teoremiyle YAKLASIK
// hacim hesaplar: V = (1/6) * sum(v0 . (v1 x v2)) her ucgen icin, origine
// gore. Bu formul ucgenlerin TUTARLI yonlendirilmis (STL/OBJ standardinin
// gerektirdigi gibi disariya bakan) normale sahip oldugunu VARSAYAR; agiz
// (delik/acik yuzey) varsa sonuc GERCEK degildir. STL/OBJ icin GERCEK bir
// BREP/katı kavrami olmadigindan bu, elde edilebilecek EN İYİ tahmindir
// (STEP/IGES icin bunun yerine OCCTBridge::volumeMm3() KULLANILMALIDIR,
// o gercek geometriden TAM DOGRU hacim verir).
inline double meshApproxVolumeMm3(const MeshData& mesh) {
    double vol = 0.0;
    for (const auto& t : mesh.triangles) {
        const Vec3& v0 = mesh.vertices[t.a].position;
        const Vec3& v1 = mesh.vertices[t.b].position;
        const Vec3& v2 = mesh.vertices[t.c].position;
        // v0 . (v1 x v2)
        const double cx = (double)v1.y * v2.z - (double)v1.z * v2.y;
        const double cy = (double)v1.z * v2.x - (double)v1.x * v2.z;
        const double cz = (double)v1.x * v2.y - (double)v1.y * v2.x;
        vol += (double)v0.x * cx + (double)v0.y * cy + (double)v0.z * cz;
    }
    return std::fabs(vol) / 6.0;
}

// Ardisik ucgen nokta listesinden (her 3 nokta bir ucgen), DUZ (flat) golgeleme
// icin pozisyon+normal VBO verisi uretir: her ucgenin normali (kenarlarin
// cross product'i) HESAPLANIR ve o ucgenin 3 kosesine de AYNI sekilde
// atanir - bu, "nerede yuzey donuyor" gorsel olarak net secilsin diye
// bilerek DUZ (paylasilmayan/smooth degil) golgeleme tercihidir; STL/OBJ/DWG
// gibi paylasilan vertex/smoothing-group bilgisi GUVENILIR OLMAYAN
// formatlarda en tutarli sonucu verir. Cikti: [x,y,z, nx,ny,nz, ...] (6
// float/vertex), dogrudan bir VBO'ya yuklenebilir.
inline std::vector<float> buildLitTriangleBuffer(const std::vector<Vec3>& triPoints) {
    std::vector<float> out;
    out.reserve(triPoints.size() * 6);
    for (size_t i = 0; i + 2 < triPoints.size(); i += 3) {
        const Vec3& a = triPoints[i];
        const Vec3& b = triPoints[i + 1];
        const Vec3& c = triPoints[i + 2];
        const Vec3 n = normalize(cross(b - a, c - a));
        for (const Vec3& p : {a, b, c}) {
            out.insert(out.end(), {p.x, p.y, p.z, n.x, n.y, n.z});
        }
    }
    return out;
}

// Ayni ardisik ucgen nokta listesinden (buildLitTriangleBuffer ile AYNI
// girdi), tel-kafes (wireframe) GORUNUM icin kenar (GL_LINES) verisi
// uretir: her ucgenin 3 kenari (a-b, b-c, c-a) ayri birer segment olarak
// eklenir. Paylasilan kenarlar TEKRARLANIR (deduplication YAPILMAZ) -
// gorsel olarak fark etmez (ayni cizgi iki kez cizilir), ve tipik parca
// boyutlari icin performans sorunu yaratmayacak kadar basit bir yaklasimdir.
// Cikti: [x,y,z, x,y,z, ...] (pozisyon-only, 3 float/vertex, normal YOK -
// tel kafes golgelendirilmez).
inline std::vector<float> buildEdgeBuffer(const std::vector<Vec3>& triPoints) {
    std::vector<float> out;
    out.reserve(triPoints.size() * 2 * 3); // ucgen basina 3 kenar x 2 nokta x 3 float
    auto pushSeg = [&out](const Vec3& p, const Vec3& q) {
        out.insert(out.end(), {p.x, p.y, p.z, q.x, q.y, q.z});
    };
    for (size_t i = 0; i + 2 < triPoints.size(); i += 3) {
        const Vec3& a = triPoints[i];
        const Vec3& b = triPoints[i + 1];
        const Vec3& c = triPoints[i + 2];
        pushSeg(a, b);
        pushSeg(b, c);
        pushSeg(c, a);
    }
    return out;
}
