#include <jni.h>
#include <string>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <android/log.h>
#include "../renderer/Renderer3D.h"
#include "../kernel/OCCTKernelAdapter.h"
#include "../kernel/mesh_reader/MeshFileReader.h"
#include "../kernel/dwg_bridge/DwgBridge.h"
#include "../measurement/Measurement.h"
#include "../geometry/Picking.h"
#include "../geometry/Mesh.h"

static Renderer3D g_renderer;
static OCCTKernelAdapter g_kernel;
static MeshData g_modelMesh;
static MeasurementManager g_measurement;
static std::string g_measurementText;
static double g_volumeMm3 = 0.0;       // yuklu modelin hacmi (STEP/IGES: OCCT'den TAM DOGRU; STL/OBJ: mesh'ten YAKLASIK)
static float g_materialDensityGCm3 = 0.0f; // kullanici malzeme kutuphanesinden secti (g/cm^3), 0 = secilmedi
static bool g_lengthUnitInch = false; // uzunluk birimi tercihi: false=mm, true=inch (aci ETKILENMEZ)

// Mesafe ("model" etiketli, aslinda hep mm) degerini kullanicinin sectigi
// birime cevirir; aci ("deg") HICBIR ZAMAN donusturulmez (birimsiz oran).
static void applyLengthUnit(double& value, std::string& unit) {
    if (unit == "model") {
        if (g_lengthUnitInch) { value *= 0.0393700787; unit = "in"; }
        else { unit = "mm"; }
    }
}
static int g_dwgUnsupportedSolidCount = 0; // DWG/DXF'te ACIS govde bulunduysa (geometriye cevrilmedi) kullaniciya bildirmek icin
static std::vector<Vec3> g_dwgLineVerts;   // DWG/DXF cizgi geometrisi - picking icin ayrica saklanir (g_modelMesh sadece ucgenleri tutar)
static void syncMeasurementHistory();

static std::string jstringToUtf8(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

// STL/OBJ dogrudan bir ucgen agi oldugu icin CAD kernel'ine (OCCT) ihtiyac
// DUYMAZ; BREP->tessellation adimi yoktur. STEP/IGES ise parametrik/BREP
// formatlar oldugu icin GERCEK bir CAD kernel'i gerektirir.
static bool isMeshFormat(const std::string& path) {
    const auto dot = path.find_last_of('.');
    if (dot == std::string::npos) return false;
    std::string ext = path.substr(dot + 1);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return ext == "stl" || ext == "obj";
}

// DWG/DXF, acadrust (Rust, MIT lisansli) uzerinden okunur. ACIS/SAT tabanli
// 3D katilar (3DSOLID/BODY) SAYILIR ama geometriye CEVRILMEZ (bkz.
// DwgBridge.h basi ve KURULUM.md).
static bool isDwgFormat(const std::string& path) {
    const auto dot = path.find_last_of('.');
    if (dot == std::string::npos) return false;
    std::string ext = path.substr(dot + 1);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return ext == "dwg" || ext == "dxf";
}

extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeInit(JNIEnv*,jobject){g_renderer.init();}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeResize(JNIEnv*,jobject,jint w,jint h){g_renderer.resize(w,h);}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeDraw(JNIEnv*,jobject){g_renderer.draw();}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeOrbit(JNIEnv*,jobject,jfloat dx,jfloat dy){g_renderer.orbit(dx,dy);}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeZoom(JNIEnv*,jobject,jfloat d){g_renderer.zoom(d);}
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeOpen(JNIEnv* env,jobject,jstring path){
    const auto p=jstringToUtf8(env,path);

    if (isMeshFormat(p)) {
        // STL/OBJ yolu: OCCT'ye bagli degildir, kernel bagli olsun olmasin calisir.
        g_modelMesh = {};
        cadviewer::MeshFileResult r = cadviewer::MeshFileReader::load(p, g_modelMesh);
        if (!r.ok) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","mesh load: %s",r.error.c_str());
            g_modelMesh = {};
            return JNI_FALSE;
        }
        if (!g_renderer.setMesh(g_modelMesh)) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","renderer mesh upload failed");
            return JNI_FALSE;
        }
        g_volumeMm3 = meshApproxVolumeMm3(g_modelMesh);
        g_dwgUnsupportedSolidCount = 0;
        g_dwgLineVerts.clear();
        return JNI_TRUE;
    }

    if (isDwgFormat(p)) {
        // DWG/DXF yolu: acadrust (Rust) uzerinden okunur. Ucgen (3DFACE) ve
        // cizgi (LINE/ARC/CIRCLE/POLYLINE) verisi AYRI AYRI Renderer3D'ye
        // verilir; hacim hesabi YAPILMAZ (DWG cizim verisi genelde kapali
        // bir katı DEGILDIR, hacim kavrami anlamsizdir).
        auto sonuc = cadviewer::DwgBridge::load(p);
        if (!sonuc.ok) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","dwg load: %s",sonuc.error.c_str());
            return JNI_FALSE;
        }
        if (!g_renderer.setDwgGeometry(sonuc.triangleVertices, sonuc.lineVertices)) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","dwg renderer upload failed");
            return JNI_FALSE;
        }
        // Picking icin: ucgen (3DFACE) verisini g_modelMesh'e de yaz (Picker::pick
        // ray-ucgen kesisimini bu yapidan okur), cizgi verisini ayri bir
        // listede (g_dwgLineVerts) sakla (Picker::pickLines bunu kullanir).
        // BUNLAR OLMADAN: DWG'de Distance/Angle olcumu icin ekrana dokunmak
        // SESSIZCE hicbir sey yapmazdi (nativePick() sadece g_modelMesh
        // ucgenlerine bakar, DWG ise onu bos birakiyordu - bu, birlesik
        // uygulamanin son kontrolunde bulunup duzeltildi).
        g_modelMesh = {};
        g_modelMesh.vertices.reserve(sonuc.triangleVertices.size());
        for (const auto& v : sonuc.triangleVertices) { MeshVertex mv; mv.position = v; g_modelMesh.vertices.push_back(mv); }
        for (size_t i = 0; i + 2 < g_modelMesh.vertices.size(); i += 3) {
            MeshTriangle t; t.a=(unsigned)i; t.b=(unsigned)(i+1); t.c=(unsigned)(i+2); t.faceId=i/3;
            g_modelMesh.triangles.push_back(t);
        }
        g_dwgLineVerts = sonuc.lineVertices;
        g_volumeMm3 = 0.0; // DWG icin agirlik hesabi desteklenmiyor
        g_dwgUnsupportedSolidCount = sonuc.unsupportedSolidCount;
        if (sonuc.unsupportedSolidCount > 0) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","dwg: %d ACIS govde geometriye cevrilemedi",sonuc.unsupportedSolidCount);
        }
        return JNI_TRUE;
    }

    // STEP/IGES yolu: gercek bir CAD kernel'i (OCCT) gerektirir.
    const auto r=g_kernel.open(p);
    if(!r.ok) __android_log_print(ANDROID_LOG_ERROR,"CADViewer","open: %s",r.error.c_str());
    if(r.ok) {
        g_modelMesh={};
        if(!g_kernel.tessellate(g_modelMesh,0.25,0.35)) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","tessellate: %s",g_kernel.lastError().c_str());
            g_kernel.close();
            return JNI_FALSE;
        }
        if(!g_renderer.setMesh(g_modelMesh)) {
            __android_log_print(ANDROID_LOG_ERROR,"CADViewer","renderer mesh upload failed");
            return JNI_FALSE;
        }
        g_volumeMm3 = g_kernel.volumeMm3(); // gercek BREP geometrisinden TAM DOGRU hacim
        g_dwgUnsupportedSolidCount = 0;
        g_dwgLineVerts.clear();
    }
    return r.ok ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeKernelAvailable(JNIEnv*,jobject){return g_kernel.available()?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeClose(JNIEnv*,jobject){g_kernel.close();g_modelMesh={};g_renderer.clear();g_volumeMm3=0.0;g_materialDensityGCm3=0.0f;g_dwgUnsupportedSolidCount=0;g_dwgLineVerts.clear();}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeFit(JNIEnv*,jobject){g_renderer.fit();}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeHome(JNIEnv*,jobject){g_renderer.home();}
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeBeginMeasurement(JNIEnv*,jobject,jint type){ g_measurement.begin(static_cast<MeasurementType>(type)); g_renderer.clearMeasurementOverlay(); }
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeClearMeasurement(JNIEnv*,jobject){ g_measurement.clear(); g_renderer.clearMeasurementOverlay(); }
// Picking is intentionally a separate boundary: renderer camera matrices and mesh intersection
// will be connected here without leaking CAD-kernel types into the Android UI layer.
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativePick(JNIEnv*,jobject,jfloat x,jfloat y){
    if(!g_renderer.hasMesh()) return JNI_FALSE;
    const Ray ray = g_renderer.screenRay(x,y);
    PickResult hit{};
    if (!g_modelMesh.triangles.empty()) {
        hit = Picker::pick(ray, g_modelMesh);
    }
    if (!hit.hit && !g_dwgLineVerts.empty()) {
        // Cizgi tabanli (DWG/DXF) geometri: sahnenin sinir kuresine oranli
        // bir tolerans kullanilir (sabit bir dunya-birimi degeri, kucuk
        // parcalarda cok gevsek, buyuk parcalarda cok siki olurdu).
        const float tolerance = std::max(0.01f, g_renderer.boundingRadius() * 0.02f);
        hit = Picker::pickLines(ray, g_dwgLineVerts, tolerance);
    }
    if(!hit.hit) return JNI_FALSE;
    if(g_measurement.pointCount()>=g_measurement.requiredPoints() && g_measurement.requiredPoints()>0) g_measurement.restart();
    g_measurement.addPoint(hit.worldPoint);
    syncMeasurementHistory();
    Vec3 points[3]{};
    const int count=g_measurement.pointCount();
    for(int i=0;i<count;++i) points[i]=g_measurement.point(i);
    g_renderer.setMeasurementPoints(points,count);
    if(g_measurement.result().valid) {
        const auto& r=g_measurement.result();
        double v = r.value; std::string u = r.unit;
        applyLengthUnit(v, u);
        char buf[64]; std::snprintf(buf, sizeof(buf), "%.3f %s", v, u.c_str());
        g_measurementText = buf;
    } else g_measurementText.clear();
    return JNI_TRUE;
}
extern "C" JNIEXPORT jint JNICALL Java_com_cadviewer_CadNative_nativeMeasurementPointCount(JNIEnv*,jobject){ return g_measurement.pointCount(); }
extern "C" JNIEXPORT jint JNICALL Java_com_cadviewer_CadNative_nativeMeasurementRequiredPoints(JNIEnv*,jobject){ return g_measurement.requiredPoints(); }
extern "C" JNIEXPORT jdouble JNICALL Java_com_cadviewer_CadNative_nativeMeasurementValue(JNIEnv*,jobject){
    double v = g_measurement.result().value; std::string u = g_measurement.result().unit;
    applyLengthUnit(v, u);
    return v;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_cadviewer_CadNative_nativeMeasurementUnit(JNIEnv* env,jobject){
    double v = g_measurement.result().value; std::string u = g_measurement.result().unit;
    applyLengthUnit(v, u);
    return env->NewStringUTF(u.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_cadviewer_CadNative_nativeMeasurementLabel(JNIEnv* env,jobject){ return env->NewStringUTF(g_measurementText.c_str()); }

extern "C" JNIEXPORT jfloatArray JNICALL Java_com_cadviewer_CadNative_nativeMeasurementLabelScreen(JNIEnv* env,jobject){
    jfloatArray out=env->NewFloatArray(3); jfloat values[3]={-1.f,-1.f,-1.f};
    if(g_measurement.result().valid && g_measurement.pointCount()>0){
        Vec3 a{}; int n=g_measurement.pointCount(); for(int i=0;i<n;++i) a=a+g_measurement.point(i); a=a*(1.f/n);
        float x,y,d; if(g_renderer.projectToScreen(a,x,y,d)){values[0]=x;values[1]=y;values[2]=d;}
    } env->SetFloatArrayRegion(out,0,3,values); return out;
}

static void syncMeasurementHistory(){ std::vector<std::vector<Vec3>> h; for(const auto& m:g_measurement.history()){ std::vector<Vec3> pts; for(int i=0;i<m.count;++i) pts.push_back(m.p[i]); h.push_back(pts);} g_renderer.setMeasurementHistory(h); }
extern "C" JNIEXPORT jint JNICALL Java_com_cadviewer_CadNative_nativeMeasurementHistoryCount(JNIEnv*,jobject){ return (jint)g_measurement.history().size(); }

extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeDeleteLastMeasurement(JNIEnv*,jobject){ if(!g_measurement.removeLast()) return JNI_FALSE; syncMeasurementHistory(); return JNI_TRUE; }

// --- Agirlik hesaplama (malzeme kutuphanesi entegrasyonu) ---
// setMaterialDensity: kullanici malzeme kutuphanesinden bir malzeme sectiginde
// Kotlin tarafi bu fonksiyonu cagirir (yogunluk, g/cm^3). 0 = secim yok.
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeSetMaterialDensity(JNIEnv*,jobject,jfloat densityGCm3){ g_materialDensityGCm3 = densityGCm3; }
extern "C" JNIEXPORT jfloat JNICALL Java_com_cadviewer_CadNative_nativeMaterialDensity(JNIEnv*,jobject){ return g_materialDensityGCm3; }
// Hacim her zaman gosterilebilir (malzeme secilmese bile) - bilgi amacli.
extern "C" JNIEXPORT jdouble JNICALL Java_com_cadviewer_CadNative_nativeVolumeCm3(JNIEnv*,jobject){ return g_volumeMm3 / 1000.0; } // mm^3 -> cm^3
// Agirlik (kg): hacim(cm^3) * yogunluk(g/cm^3) / 1000. Malzeme secilmediyse
// (yogunluk 0) ya da model yuklu degilse (hacim 0) 0 doner - Kotlin tarafi
// bu durumda "malzeme secin" mesaji gosterir.
extern "C" JNIEXPORT jdouble JNICALL Java_com_cadviewer_CadNative_nativeWeightKg(JNIEnv*,jobject){
    if (g_volumeMm3 <= 0.0 || g_materialDensityGCm3 <= 0.0f) return 0.0;
    const double volumeCm3 = g_volumeMm3 / 1000.0;
    const double weightGrams = volumeCm3 * (double)g_materialDensityGCm3;
    return weightGrams / 1000.0;
}
// STEP/IGES (gercek BREP) ile mi yoksa STL/OBJ (yaklasik mesh) ile mi
// hesaplandigini UI'da ayirt etmek icin (kullaniciya dogruluk beklentisini
// dogru vermek amaciyla): true = OCCT'den tam dogru, false = mesh yaklasimi.
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeVolumeIsExact(JNIEnv*,jobject){ return g_kernel.isOpen() ? JNI_TRUE : JNI_FALSE; }
extern "C" JNIEXPORT jint JNICALL Java_com_cadviewer_CadNative_nativeDwgUnsupportedSolidCount(JNIEnv*,jobject){ return g_dwgUnsupportedSolidCount; }
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeHasModel(JNIEnv*,jobject){ return g_renderer.hasMesh() ? JNI_TRUE : JNI_FALSE; }

// --- Kesit (section/clipping plane) gorunumu ---
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeSetSectionEnabled(JNIEnv*,jobject,jboolean enabled){ g_renderer.setSectionEnabled(enabled == JNI_TRUE); }
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeSectionEnabled(JNIEnv*,jobject){ return g_renderer.sectionEnabled() ? JNI_TRUE : JNI_FALSE; }
// axis: 0=X,1=Y,2=Z. fraction: -1..1 (merkeze gore yaricap oraninda kaydirma).
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeSetSectionPlane(JNIEnv*,jobject,jint axis,jfloat fraction){ g_renderer.setSectionPlane((int)axis, fraction); }

// --- Uzunluk birimi (mm/inch) ---
// Sadece MESAFE ("model" etiketli) degerleri etkiler; aci ("deg") ETKILENMEZ.
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeSetLengthUnit(JNIEnv*,jobject,jboolean inch){ g_lengthUnitInch = (inch == JNI_TRUE); }
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeLengthUnitIsInch(JNIEnv*,jobject){ return g_lengthUnitInch ? JNI_TRUE : JNI_FALSE; }

// --- Parca boyutu (X x Y x Z) ---
// Her zaman MM cinsinden doner (native tarafta HAM deger); birim
// donusumu (inch gosterimi icin) Kotlin tarafinda, ayni sabit (0.0393701)
// ile yapilir - bu, dogal olarak sadece GORUNTULEME katmanini etkiler.
extern "C" JNIEXPORT jfloatArray JNICALL Java_com_cadviewer_CadNative_nativeModelSizeMm(JNIEnv* env,jobject){
    jfloatArray out=env->NewFloatArray(3);
    Vec3 s = g_renderer.boundingSize();
    jfloat values[3]={s.x,s.y,s.z};
    env->SetFloatArrayRegion(out,0,3,values);
    return out;
}

// --- Tel kafes / dolu yuzey gorunumu (ana ucgen mesh icin) ---
// DWG'nin kendi cizgi geometrisi (LINE/ARC/vb) bu ayardan ETKILENMEZ.
extern "C" JNIEXPORT void JNICALL Java_com_cadviewer_CadNative_nativeSetWireframeMode(JNIEnv*,jobject,jboolean enabled){ g_renderer.setWireframeMode(enabled == JNI_TRUE); }
extern "C" JNIEXPORT jboolean JNICALL Java_com_cadviewer_CadNative_nativeWireframeMode(JNIEnv*,jobject){ return g_renderer.wireframeMode() ? JNI_TRUE : JNI_FALSE; }
