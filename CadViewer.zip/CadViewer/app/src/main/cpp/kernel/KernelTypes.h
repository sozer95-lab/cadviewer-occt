#pragma once
#include <cstdint>
#include <string>

enum class EntityType : uint8_t { None, Vertex, Edge, Face, Solid, Part };
struct EntityRef { uint64_t id=0; EntityType type=EntityType::None; };
struct KernelOpenResult { bool ok=false; std::string error; };

// OCCTBridge::load() modelin hangi birimde geldigini bildirir. STEP/IGES
// dosyalari cogunlukla milimetre kullanir; ileride gercek OCCT entegrasyonu
// dosyanin kendi birim bilgisini okuyup bunu doldurabilir. Su an icin
// OCCTBridge sabit olarak Millimeter donduruyor (bkz. OCCTBridge.cpp).
enum class ModelUnit : uint8_t { Millimeter, Centimeter, Meter, Inch };
