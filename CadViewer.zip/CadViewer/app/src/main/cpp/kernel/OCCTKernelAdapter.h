#pragma once
#include "KernelAdapter.h"
#include "occt_bridge/OCCTBridge.h"
#include <string>

class OCCTKernelAdapter final : public KernelAdapter {
public:
    OCCTKernelAdapter() = default;
    KernelOpenResult open(const std::string& path) override;
    void close() override;
    bool isOpen() const override { return open_; }
    const std::string& lastError() const override { return error_; }
    bool tessellate(MeshData& out, double linearDeflection, double angularDeflection) override;
    bool available() const { return bridge_.available(); }
    double volumeMm3() const { return bridge_.volumeMm3(); }
private:
    bool open_ = false;
    std::string path_;
    std::string error_;
    cadviewer::OCCTBridge bridge_;
};
