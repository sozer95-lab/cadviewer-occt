#pragma once
#include <string>
#include "KernelTypes.h"
#include "../geometry/Mesh.h"

class KernelAdapter {
public:
    virtual ~KernelAdapter() = default;
    virtual KernelOpenResult open(const std::string& path)=0;
    virtual void close()=0;
    virtual bool isOpen() const=0;
    virtual const std::string& lastError() const=0;
    virtual bool tessellate(MeshData& out, double linearDeflection, double angularDeflection)=0;
};
