#include "OCCTKernelAdapter.h"
#include "occt_bridge/OCCTBuildConfig.h"
#include <algorithm>
#include <cctype>
#include <cstring>

static bool hasExt(const std::string& p, const char* ext) {
    if (p.size() < std::strlen(ext)) return false;
    std::string a=p.substr(p.size()-std::strlen(ext)), b=ext;
    std::transform(a.begin(),a.end(),a.begin(),[](unsigned char c){return char(std::tolower(c));});
    std::transform(b.begin(),b.end(),b.begin(),[](unsigned char c){return char(std::tolower(c));});
    return a==b;
}

KernelOpenResult OCCTKernelAdapter::open(const std::string& path) {
    close();
    if (!(hasExt(path,".step")||hasExt(path,".stp")||hasExt(path,".iges")||hasExt(path,".igs"))) {
        error_="Unsupported CAD format. Expected STEP/STP/IGES/IGS.";
        return {false,error_};
    }
    auto r = bridge_.load(path);
    if (!r.ok) { error_=r.error; return {false,error_}; }
    path_=path; open_=true; return {true,{}};
}

void OCCTKernelAdapter::close() { bridge_.clear(); open_=false; path_.clear(); error_.clear(); }

bool OCCTKernelAdapter::tessellate(MeshData& out, double linearDeflection, double angularDeflection) {
    if (!open_) { error_="No CAD model is open."; return false; }
    if (!bridge_.tessellate(out, linearDeflection, angularDeflection)) {
        error_="OCCT tessellation failed."; return false;
    }
    return true;
}
