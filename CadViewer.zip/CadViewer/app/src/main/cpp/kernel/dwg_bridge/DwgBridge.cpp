#include "DwgBridge.h"

// CADVIEWER_HAS_DWG, CMakeLists.txt tarafindan third_party/dwg_bridge/arm64-v8a/
// libdwg_bridge.a dosyasinin VARLIGINA gore ayarlanir (bkz. CMakeLists.txt
// yorumu). Bu bayrak 0 iken dwg_bridge.h/Rust fonksiyonlari HIC INCLUDE
// EDILMEZ/CAGRILMAZ - boylece .a dosyasi eksikken bile proje sorunsuzca
// derlenir (OCCTBridge.cpp'nin CADVIEWER_HAS_OCCT ile yaptigi gibi).
#if CADVIEWER_HAS_DWG
#include "../../third_party/dwg_bridge/include/dwg_bridge.h"
#endif

namespace cadviewer {

DwgLoadOutcome DwgBridge::load(const std::string& path) {
    DwgLoadOutcome out;
#if !CADVIEWER_HAS_DWG
    (void)path;
    out.ok = false;
    out.error = "DWG/DXF kernel (dwg_bridge Rust kutuphanesi) bu derlemede yok - "
                "bkz. third_party/dwg_bridge/README.md";
    return out;
#else
    DwgLoadResult r = dwg_load(path.c_str());
    if (!r.ok) {
        out.ok = false;
        out.error = r.error_message ? std::string(r.error_message) : std::string("bilinmeyen DWG/DXF hatasi");
        dwg_free(r);
        return out;
    }
    out.ok = true;
    out.triangleVertices.reserve(r.tri_point_count);
    for (size_t i = 0; i < r.tri_point_count; ++i) {
        out.triangleVertices.push_back({r.tri_points[i].x, r.tri_points[i].y, r.tri_points[i].z});
    }
    out.lineVertices.reserve(r.line_point_count);
    for (size_t i = 0; i < r.line_point_count; ++i) {
        out.lineVertices.push_back({r.line_points[i].x, r.line_points[i].y, r.line_points[i].z});
    }
    out.unsupportedSolidCount = r.unsupported_solid_count;
    dwg_free(r); // Rust tarafinda ayrilan bellek - kopyaladiktan SONRA serbest birak
    return out;
#endif
}

} // namespace cadviewer

