#pragma once
#include <string>
#include <vector>
#include "../../core/Vec3.h"

namespace cadviewer {

struct DwgLoadOutcome {
    bool ok = false;
    std::string error;
    std::vector<Vec3> triangleVertices;  // her 3 nokta bir ucgen (3DFACE'ten)
    std::vector<Vec3> lineVertices;      // her 2 nokta bir cizgi segmenti (LINE/ARC/CIRCLE/POLYLINE'dan)
    int unsupportedSolidCount = 0;       // ACIS/SAT govde (3DSOLID/BODY) - geometriye CEVRILMEDI
};

// dwg_bridge (Rust, acadrust ustune ince bir FFI katmani - MIT lisansli)
// kutuphanesini cagirir. STEP/IGES (OCCTBridge) ve STL/OBJ (MeshFileReader)
// akislarindan TAMAMEN BAGIMSIZDIR; DWG/DXF icin ayri bir veri yoludur
// (ucgen + cizgi olarak DONER, tek bir MeshData DEGIL, cunku DWG cizim
// verisi cogunlukla cizgi tabanlidir).
class DwgBridge {
public:
    static DwgLoadOutcome load(const std::string& path);
};

} // namespace cadviewer
