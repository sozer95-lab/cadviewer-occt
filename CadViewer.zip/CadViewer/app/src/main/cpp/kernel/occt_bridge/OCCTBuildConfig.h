#pragma once
// Generated build switch. Set CADVIEWER_HAS_OCCT=1 only when the real
// OCCT ARM64 libraries and headers are present under third_party/occt.
#ifndef CADVIEWER_HAS_OCCT
#define CADVIEWER_HAS_OCCT 0
#endif
