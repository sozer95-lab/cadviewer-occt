#include "OCCTBridge.h"
#include "OCCTBuildConfig.h"
#include <cctype>

#if CADVIEWER_HAS_OCCT
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRep_Tool.hxx>
#include <Poly_Triangulation.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Face.hxx>
#include <TopAbs.hxx>
#include <STEPCAFControl_Reader.hxx>
#include <IGESCAFControl_Reader.hxx>
#include <XCAFApp_Application.hxx>
#include <XCAFDoc_DocumentTool.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <TDocStd_Document.hxx>
#include <TDF_LabelSequence.hxx>
#include <gp_Pnt.hxx>
#include <BRepGProp.hxx>
#include <GProp_GProps.hxx>
#endif

namespace cadviewer {
struct OCCTBridge::Impl {
#if CADVIEWER_HAS_OCCT
    Handle(XCAFApp_Application) app;
    Handle(TDocStd_Document) doc;
    TopoDS_Shape shape;
#endif
};

OCCTBridge::OCCTBridge() : impl_(new Impl()) {}
OCCTBridge::~OCCTBridge() { clear(); delete impl_; }

bool OCCTBridge::available() const {
#if CADVIEWER_HAS_OCCT
    return true;
#else
    return false;
#endif
}

void OCCTBridge::clear() {
#if CADVIEWER_HAS_OCCT
    impl_->shape.Nullify();
    impl_->doc.Nullify();
    impl_->app.Nullify();
#endif
}

OCCTLoadResult OCCTBridge::load(const std::string& path) {
    clear();
#if !CADVIEWER_HAS_OCCT
    return {false, "OCCT ARM64 native libraries are not bundled in this build", ModelUnit::Millimeter};
#else
    impl_->app = XCAFApp_Application::GetApplication();
    impl_->app->NewDocument("MDTV-XCAF", impl_->doc);

    const auto dot = path.find_last_of('.');
    std::string ext = dot == std::string::npos ? "" : path.substr(dot + 1);
    for (char& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

    if (ext == "step" || ext == "stp") {
        STEPCAFControl_Reader reader;
        if (reader.ReadFile(path.c_str()) != IFSelect_RetDone)
            return {false, "STEP read failed", ModelUnit::Millimeter};
        if (!reader.Transfer(impl_->doc))
            return {false, "STEP transfer failed", ModelUnit::Millimeter};
    } else if (ext == "iges" || ext == "igs") {
        IGESCAFControl_Reader reader;
        if (reader.ReadFile(path.c_str()) != IFSelect_RetDone)
            return {false, "IGES read failed", ModelUnit::Millimeter};
        if (!reader.Transfer(impl_->doc))
            return {false, "IGES transfer failed", ModelUnit::Millimeter};
    } else {
        return {false, "Unsupported CAD format", ModelUnit::Millimeter};
    }

    Handle(XCAFDoc_ShapeTool) shapeTool = XCAFDoc_DocumentTool::ShapeTool(impl_->doc->Main());
    TDF_LabelSequence roots;
    shapeTool->GetFreeShapes(roots);
    for (Standard_Integer i = 1; i <= roots.Length(); ++i) {
        TopoDS_Shape s = shapeTool->GetShape(roots.Value(i));
        if (!s.IsNull()) { impl_->shape = s; break; }
    }
    if (impl_->shape.IsNull()) return {false, "No shape found in CAD document", ModelUnit::Millimeter};
    return {true, {}, ModelUnit::Millimeter};
#endif
}

bool OCCTBridge::tessellate(MeshData& out, double linearDeflection, double angularDeflection) {
#if !CADVIEWER_HAS_OCCT
    (void)out; (void)linearDeflection; (void)angularDeflection; return false;
#else
    if (impl_->shape.IsNull()) return false;
    BRepMesh_IncrementalMesh mesher(impl_->shape, linearDeflection, false, angularDeflection, false);
    if (!mesher.IsDone()) return false;
    out.vertices.clear(); out.triangles.clear();

    uint64_t faceId = 1;
    for (TopExp_Explorer ex(impl_->shape, TopAbs_FACE); ex.More(); ex.Next(), ++faceId) {
        const TopoDS_Face face = TopoDS::Face(ex.Current());
        TopLoc_Location loc;
        Handle(Poly_Triangulation) tri = BRep_Tool::Triangulation(face, loc);
        if (tri.IsNull()) continue;
        const unsigned base = static_cast<unsigned>(out.vertices.size());
        for (Standard_Integer i = 1; i <= tri->NbNodes(); ++i) {
            gp_Pnt p = tri->Node(i); p.Transform(loc.Transformation());
            MeshVertex v; v.position = {float(p.X()), float(p.Y()), float(p.Z())}; v.normal = {0,0,0};
            out.vertices.push_back(v);
        }
        for (Standard_Integer i = 1; i <= tri->NbTriangles(); ++i) {
            Standard_Integer a,b,c; tri->Triangle(i).Get(a,b,c);
            MeshTriangle t; t.a=base+unsigned(a)-1; t.b=base+unsigned(b)-1; t.c=base+unsigned(c)-1; t.faceId=faceId;
            out.triangles.push_back(t);
        }
    }
    return !out.vertices.empty() && !out.triangles.empty();
#endif
}

double OCCTBridge::volumeMm3() const {
#if !CADVIEWER_HAS_OCCT
    return 0.0;
#else
    if (impl_->shape.IsNull()) return 0.0;
    GProp_GProps props;
    // BRepGProp::VolumeProperties gercek BREP geometrisinden (tesselasyon
    // yaklasikligindan DEGIL) tam dogru hacim hesaplar. Kapali olmayan
    // (acik yuzeyli / hatali) katilarda sonuc anlamsiz olabilir; boyle
    // durumda OCCT genelde 0'a yakin ya da tutarsiz bir deger dondurur,
    // cagiran taraf (CadNative.cpp) negatif/sifir degerleri filtreler.
    BRepGProp::VolumeProperties(impl_->shape, props);
    return props.Mass(); // "Mass" burada yogunluk=1 varsayimiyla HACMI (mm^3) verir
#endif
}
} // namespace cadviewer
