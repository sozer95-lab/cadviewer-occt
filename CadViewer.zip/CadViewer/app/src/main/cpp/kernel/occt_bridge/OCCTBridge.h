#pragma once
#include <string>
#include <vector>
#include "../../geometry/Mesh.h"
#include "../KernelTypes.h"

namespace cadviewer {

struct OCCTLoadResult {
    bool ok = false;
    std::string error;
    ModelUnit unit = ModelUnit::Millimeter;
};

class OCCTBridge {
public:
    OCCTBridge();
    ~OCCTBridge();

    OCCTLoadResult load(const std::string& path);
    bool tessellate(MeshData& out, double linearDeflection, double angularDeflection);
    void clear();

    // GERCEK geometriden (tesselasyon yaklaşıklığından DEĞİL) tam doğru hacim
    // (mm^3). Model yuklu degilse 0 doner. STEP/IGES biriminin milimetre
    // oldugu varsayilir (bkz. ModelUnit - su an OCCTBridge::load() hep
    // Millimeter donuyor).
    double volumeMm3() const;

    bool available() const;

private:
    struct Impl;
    Impl* impl_;
};

} // namespace cadviewer
