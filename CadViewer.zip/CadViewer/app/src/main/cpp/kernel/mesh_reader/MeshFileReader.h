#pragma once
#include <string>
#include "../../geometry/Mesh.h"

// STL (ASCII + binary) ve OBJ (yalnizca geometri: v/f) dosyalarini dogrudan
// MeshData'ya okur. Bu, OCCT gibi bir CAD kernel'ine ihtiyac DUYMAZ: STL/OBJ
// zaten hazir bir ucgen agidir, BREP->tessellation adimi gerekmez. STEP/IGES
// (parametrik/BREP formatlar) icin bu okuyucu KULLANILMAZ; onlar hala
// OCCTKernelAdapter uzerinden gercek bir CAD kernel'i gerektirir.
namespace cadviewer {

struct MeshFileResult {
    bool ok = false;
    std::string error;
};

class MeshFileReader {
public:
    // path'in uzantisina bakarak (.stl/.obj, buyuk/kucuk harf duyarsiz) dogru
    // ayristiriciyi secer. Desteklenmeyen bir uzanti icin ok=false doner.
    static MeshFileResult load(const std::string& path, MeshData& out);

    // Ayri ayri da cagrilabilir (uzanti kontrolu olmadan, dogrudan format
    // secerek).
    static MeshFileResult loadStl(const std::string& path, MeshData& out);
    static MeshFileResult loadObj(const std::string& path, MeshData& out);
};

} // namespace cadviewer
