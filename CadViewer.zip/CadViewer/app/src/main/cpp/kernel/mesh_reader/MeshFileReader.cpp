#include "MeshFileReader.h"
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdint>
#include <cctype>
#include <algorithm>
#include <vector>

namespace cadviewer {

namespace {

std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

std::string extensionOf(const std::string& path) {
    const auto dot = path.find_last_of('.');
    if (dot == std::string::npos) return "";
    return lower(path.substr(dot + 1));
}

// Bir metin dosyasinin (STL ASCII / OBJ) tum satirlarini okur.
bool readAllLines(const std::string& path, std::vector<std::string>& lines, std::string& error) {
    std::ifstream in(path);
    if (!in) { error = "File could not be opened: " + path; return false; }
    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back(); // CRLF guvenligi
        lines.push_back(line);
    }
    return true;
}

// -------- STL --------

// Binary STL: 80 byte baslik + 4 byte (uint32 LE) ucgen sayisi + ucgen basina
// 50 byte (12 byte normal + 3x12 byte vertex + 2 byte oznitelik, kullanilmaz).
// Bir dosyanin binary mi ASCII mi oldugunu ANLAMAK icin dosyanin ILK
// KELIMESININ "solid" olup olmamasi GUVENILIR DEGILDIR (bazi binary STL
// dosyalari da 80 baytlik baslikta rastlantisal olarak "solid" kelimesiyle
// baslayabilir). Guvenilir tek yontem: dosyanin GERCEK boyutunun, binary
// formatin ONGORDUGU boyutla (80+4+n*50) BIREBIR eslesip eslesmedigine
// bakmaktir.
MeshFileResult tryLoadStlBinary(const std::string& path, MeshData& out, bool& sizeMatched) {
    sizeMatched = false;
    std::ifstream in(path, std::ios::binary);
    if (!in) return {false, "File could not be opened: " + path};

    in.seekg(0, std::ios::end);
    const std::streamoff fileSize = in.tellg();
    in.seekg(0, std::ios::beg);

    if (fileSize < 84) return {false, "File too small for binary STL"};

    char header[80];
    in.read(header, 80);
    uint32_t triCount = 0;
    in.read(reinterpret_cast<char*>(&triCount), 4);
    if (!in) return {false, "Failed to read binary STL header"};

    const std::streamoff expected = 84 + (std::streamoff)triCount * 50;
    if (expected != fileSize) return {false, "Size mismatch, not binary STL"};
    sizeMatched = true;

    out.vertices.clear();
    out.triangles.clear();
    out.vertices.reserve((size_t)triCount * 3);
    out.triangles.reserve(triCount);

    for (uint32_t i = 0; i < triCount; ++i) {
        float normal[3];
        float v[3][3];
        in.read(reinterpret_cast<char*>(normal), 12);
        for (int k = 0; k < 3; ++k) in.read(reinterpret_cast<char*>(v[k]), 12);
        uint16_t attr = 0;
        in.read(reinterpret_cast<char*>(&attr), 2);
        if (!in) return {false, "Unexpected end of binary STL data"};

        const unsigned base = (unsigned)out.vertices.size();
        for (int k = 0; k < 3; ++k) {
            MeshVertex mv;
            mv.position = {v[k][0], v[k][1], v[k][2]};
            mv.normal = {normal[0], normal[1], normal[2]};
            out.vertices.push_back(mv);
        }
        MeshTriangle t; t.a = base; t.b = base + 1; t.c = base + 2; t.faceId = i + 1;
        out.triangles.push_back(t);
    }
    if (out.triangles.empty()) return {false, "Binary STL contains no triangles"};
    return {true, {}};
}

MeshFileResult loadStlAscii(const std::string& path, MeshData& out) {
    std::vector<std::string> lines;
    std::string err;
    if (!readAllLines(path, lines, err)) return {false, err};

    out.vertices.clear();
    out.triangles.clear();
    std::vector<Vec3> pending;
    uint64_t faceId = 1;

    for (const auto& raw : lines) {
        std::istringstream ss(raw);
        std::string tok;
        ss >> tok;
        if (tok == "vertex") {
            float x = 0, y = 0, z = 0;
            ss >> x >> y >> z;
            pending.push_back({x, y, z});
            if (pending.size() == 3) {
                const unsigned base = (unsigned)out.vertices.size();
                for (const auto& p : pending) {
                    MeshVertex mv; mv.position = p; mv.normal = {0, 0, 0};
                    out.vertices.push_back(mv);
                }
                MeshTriangle t; t.a = base; t.b = base + 1; t.c = base + 2; t.faceId = faceId++;
                out.triangles.push_back(t);
                pending.clear();
            }
        }
    }
    if (out.triangles.empty()) return {false, "ASCII STL contains no facets (expected 'vertex' lines)"};
    return {true, {}};
}

// -------- OBJ --------

// "3", "3/2", "3/2/1", "3//1" bicimlerinden ilk sayiyi (vertex index) cikarir.
// OBJ indeksleri 1 tabanlidir; negatif indeksler son eklenen vertex'e gore
// GORELIDIR (-1 = en son eklenen). vertexCount, o ana kadar okunan vertex
// sayisidir (negatif indeksi cozmek icin gerekli).
bool parseObjIndex(const std::string& token, long vertexCount, long& outIndex) {
    if (token.empty()) return false;
    const auto slash = token.find('/');
    const std::string idxStr = slash == std::string::npos ? token : token.substr(0, slash);
    if (idxStr.empty()) return false;
    long v = 0;
    try { v = std::stol(idxStr); } catch (...) { return false; }
    if (v < 0) v = vertexCount + v + 1; // -1 -> son vertex
    if (v <= 0) return false;
    outIndex = v - 1; // 0 tabanliya cevir
    return true;
}

MeshFileResult loadObjImpl(const std::string& path, MeshData& out) {
    std::vector<std::string> lines;
    std::string err;
    if (!readAllLines(path, lines, err)) return {false, err};

    out.vertices.clear();
    out.triangles.clear();
    std::vector<Vec3> positions;
    uint64_t faceId = 1;

    for (const auto& raw : lines) {
        if (raw.empty() || raw[0] == '#') continue;
        std::istringstream ss(raw);
        std::string tok;
        ss >> tok;
        if (tok == "v") {
            float x = 0, y = 0, z = 0;
            ss >> x >> y >> z;
            positions.push_back({x, y, z});
        } else if (tok == "f") {
            std::vector<long> idx;
            std::string piece;
            while (ss >> piece) {
                long resolved = 0;
                if (parseObjIndex(piece, (long)positions.size(), resolved) &&
                    resolved >= 0 && resolved < (long)positions.size()) {
                    idx.push_back(resolved);
                }
            }
            if (idx.size() < 3) continue;
            // Fan triangulation: 4+ koseli yuzeyler icin (0,1,2),(0,2,3),...
            for (size_t k = 1; k + 1 < idx.size(); ++k) {
                const unsigned base = (unsigned)out.vertices.size();
                MeshVertex a, b, c;
                a.position = positions[idx[0]];
                b.position = positions[idx[k]];
                c.position = positions[idx[k + 1]];
                a.normal = b.normal = c.normal = {0, 0, 0};
                out.vertices.push_back(a);
                out.vertices.push_back(b);
                out.vertices.push_back(c);
                MeshTriangle t; t.a = base; t.b = base + 1; t.c = base + 2; t.faceId = faceId;
                out.triangles.push_back(t);
            }
            ++faceId;
        }
    }
    if (out.triangles.empty()) return {false, "OBJ contains no usable faces (expected 'f' lines referencing 'v' vertices)"};
    return {true, {}};
}

} // namespace

MeshFileResult MeshFileReader::loadStl(const std::string& path, MeshData& out) {
    bool sizeMatched = false;
    auto bin = tryLoadStlBinary(path, out, sizeMatched);
    if (sizeMatched) return bin; // boyut binary formatla eslesti: kesin binary, sonuc ne olursa olsun bunu dondur
    return loadStlAscii(path, out);
}

MeshFileResult MeshFileReader::loadObj(const std::string& path, MeshData& out) {
    return loadObjImpl(path, out);
}

MeshFileResult MeshFileReader::load(const std::string& path, MeshData& out) {
    const std::string ext = extensionOf(path);
    if (ext == "stl") return loadStl(path, out);
    if (ext == "obj") return loadObj(path, out);
    return {false, "Unsupported mesh format: ." + ext + " (expected .stl or .obj)"};
}

} // namespace cadviewer
