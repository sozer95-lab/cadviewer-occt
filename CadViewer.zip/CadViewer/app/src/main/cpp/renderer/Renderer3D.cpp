#include "Renderer3D.h"
#include <algorithm>

// Ana govde (ucgen mesh) shader'i: DUZ (flat) golgeleme + kesit (section)
// destegi. Isik, kameraya SABIT (headlamp / bas lambasi) - yani orbit
// yaparken isik HER ZAMAN goruntuleyenin bakis yonunden gelir, bu klasik
// bir CAD goruntuleyici konvansiyonudur (nesne nereye donerse donsun
// makul sekilde aydinlatilmis kalir). uViewRot, view matrisinin SADECE
// rotasyon kismidir (translate haric) - normal vektorleri sadece
// donduruluir, oteleme normal yonunu ETKILEMEZ.
static const char* VS=R"(#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
uniform mat4 uMVP;
uniform mat4 uViewRot;
out vec3 vViewNormal;
out vec3 vWorldPos;
void main(){
    gl_Position = uMVP * vec4(aPos, 1.0);
    vViewNormal = (uViewRot * vec4(aNormal, 0.0)).xyz;
    vWorldPos = aPos;
})";
static const char* FS=R"(#version 300 es
precision mediump float;
in vec3 vViewNormal;
in vec3 vWorldPos;
uniform bool uSectionEnabled;
uniform vec3 uSectionNormal;
uniform float uSectionD;
out vec4 FragColor;
void main(){
    if (uSectionEnabled && dot(uSectionNormal, vWorldPos) > uSectionD) discard;
    vec3 n = normalize(vViewNormal);
    float diff = max(dot(n, vec3(0.0, 0.0, 1.0)), 0.0);
    float lighting = 0.35 + 0.65 * diff;
    FragColor = vec4(vec3(0.72, 0.78, 0.86) * lighting, 1.0);
})";

// Cizgi (DWG/DXF wireframe) shader'i: golgeleme YOK (ince cizgiler icin
// anlamsiz), sadece kesit destegi + duz renk.
static const char* WVS=R"(#version 300 es
layout(location=0) in vec3 aPos;
uniform mat4 uMVP;
out vec3 vWorldPos;
void main(){ gl_Position = uMVP * vec4(aPos, 1.0); vWorldPos = aPos; })";
static const char* WFS=R"(#version 300 es
precision mediump float;
in vec3 vWorldPos;
uniform bool uSectionEnabled;
uniform vec3 uSectionNormal;
uniform float uSectionD;
out vec4 FragColor;
void main(){
    if (uSectionEnabled && dot(uSectionNormal, vWorldPos) > uSectionD) discard;
    FragColor = vec4(0.85, 0.65, 0.25, 1.0);
})";

static const char* OVS=R"(#version 300 es
layout(location=0) in vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);gl_PointSize=14.0;})";
static const char* OFS=R"(#version 300 es
precision mediump float; out vec4 FragColor; void main(){FragColor=vec4(1.0,0.75,0.1,1.0);})";
static GLuint compile(GLenum t,const char*s){GLuint x=glCreateShader(t);glShaderSource(x,1,&s,nullptr);glCompileShader(x);return x;}
static GLuint linkProgram(const char* vsSrc, const char* fsSrc){
    GLuint vs=compile(GL_VERTEX_SHADER,vsSrc), fs=compile(GL_FRAGMENT_SHADER,fsSrc);
    GLuint p=glCreateProgram(); glAttachShader(p,vs); glAttachShader(p,fs); glLinkProgram(p);
    glDeleteShader(vs); glDeleteShader(fs); return p;
}
static Mat4 mul(const Mat4&a,const Mat4&b){Mat4 r{};for(int c=0;c<4;c++)for(int row=0;row<4;row++)for(int k=0;k<4;k++)r.m[c*4+row]+=a.m[k*4+row]*b.m[c*4+k];return r;}
static Mat4 translate(float x,float y,float z){Mat4 r=Mat4::identity();r.m[12]=x;r.m[13]=y;r.m[14]=z;return r;}
static Mat4 rotX(float a){Mat4 r=Mat4::identity();float c=cosf(a),s=sinf(a);r.m[5]=c;r.m[6]=s;r.m[9]=-s;r.m[10]=c;return r;}
static Mat4 rotY(float a){Mat4 r=Mat4::identity();float c=cosf(a),s=sinf(a);r.m[0]=c;r.m[2]=-s;r.m[8]=s;r.m[10]=c;return r;}
void Renderer3D::updateProjection(){projection_=Mat4::perspective(1.0f,float(width_)/height_,0.01f,std::max(100.f,distance_+radius_*20.f));}
void Renderer3D::init(){
    GLuint ovs=compile(GL_VERTEX_SHADER,OVS),ofs=compile(GL_FRAGMENT_SHADER,OFS);
    overlayProgram_=glCreateProgram();glAttachShader(overlayProgram_,ovs);glAttachShader(overlayProgram_,ofs);glLinkProgram(overlayProgram_);glDeleteShader(ovs);glDeleteShader(ofs);
    glGenVertexArrays(1,&overlayVao_);glGenBuffers(1,&overlayVbo_);
    program_ = linkProgram(VS, FS);
    glGenVertexArrays(1,&vao_);glGenBuffers(1,&vbo_);
    wireProgram_ = linkProgram(WVS, WFS);
    glEnable(GL_DEPTH_TEST);glClearColor(.08f,.08f,.08f,1);
}
void Renderer3D::resize(int w,int h){width_=w;height_=h>0?h:1;glViewport(0,0,width_,height_);updateProjection();}
void Renderer3D::orbit(float dx,float dy){yaw_+=dx*.01f;pitch_=std::max(-1.5f,std::min(1.5f,pitch_+dy*.01f));}
void Renderer3D::zoom(float d){distance_=std::max(radius_*.15f,distance_*(1.f-d*.01f));}
void Renderer3D::fit(){distance_=std::max(.1f,radius_/tanf(.5f)*1.35f);updateProjection();}
void Renderer3D::home(){yaw_=0;pitch_=0;fit();}
bool Renderer3D::setMesh(const MeshData&m){
    Vec3 mn{},mx{};bool first=true;
    for(const auto&v:m.vertices){if(first){mn=mx=v.position;first=false;}else{mn.x=std::min(mn.x,v.position.x);mn.y=std::min(mn.y,v.position.y);mn.z=std::min(mn.z,v.position.z);mx.x=std::max(mx.x,v.position.x);mx.y=std::max(mx.y,v.position.y);mx.z=std::max(mx.z,v.position.z);}}
    center_=(mn+mx)*.5f;radius_=std::max(.001f,length(mx-mn)*.5f);
    boundsMin_=mn;boundsMax_=mx;
    std::vector<Vec3> triPoints; triPoints.reserve(m.triangles.size()*3);
    for(const auto&t:m.triangles){if(t.a>=m.vertices.size()||t.b>=m.vertices.size()||t.c>=m.vertices.size())continue;for(unsigned i:{t.a,t.b,t.c})triPoints.push_back(m.vertices[i].position);}
    std::vector<float> d = buildLitTriangleBuffer(triPoints);
    vertexCount_=triPoints.size();wireVertexCount_=0;
    if(!vbo_||!vao_)return false;
    glBindVertexArray(vao_);glBindBuffer(GL_ARRAY_BUFFER,vbo_);
    glBufferData(GL_ARRAY_BUFFER,d.size()*sizeof(float),d.empty()?nullptr:d.data(),GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);
    glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
    glBindVertexArray(0);
    std::vector<float> edgeData = buildEdgeBuffer(triPoints);
    edgeVertexCount_ = edgeData.size()/3;
    if(!edgeVbo_) glGenBuffers(1,&edgeVbo_);
    if(!edgeVao_) glGenVertexArrays(1,&edgeVao_);
    glBindVertexArray(edgeVao_);glBindBuffer(GL_ARRAY_BUFFER,edgeVbo_);
    glBufferData(GL_ARRAY_BUFFER,edgeData.size()*sizeof(float),edgeData.empty()?nullptr:edgeData.data(),GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glBindVertexArray(0);
    fit();return vertexCount_>0;
}

bool Renderer3D::setDwgGeometry(const std::vector<Vec3>& triVerts, const std::vector<Vec3>& lineVerts) {
    Vec3 mn{}, mx{}; bool first = true;
    auto extend = [&](const Vec3& p) {
        if (first) { mn = mx = p; first = false; return; }
        mn.x=std::min(mn.x,p.x); mn.y=std::min(mn.y,p.y); mn.z=std::min(mn.z,p.z);
        mx.x=std::max(mx.x,p.x); mx.y=std::max(mx.y,p.y); mx.z=std::max(mx.z,p.z);
    };
    for (const auto& p : triVerts) extend(p);
    for (const auto& p : lineVerts) extend(p);
    center_ = (mn + mx) * .5f;
    radius_ = std::max(.001f, length(mx - mn) * .5f);
    boundsMin_=mn;boundsMax_=mx;

    std::vector<float> triData = buildLitTriangleBuffer(triVerts);
    vertexCount_ = triVerts.size();
    if (vbo_ && vao_) {
        glBindVertexArray(vao_);
        glBindBuffer(GL_ARRAY_BUFFER, vbo_);
        glBufferData(GL_ARRAY_BUFFER, triData.size()*sizeof(float), triData.empty()?nullptr:triData.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);
        glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
        glBindVertexArray(0);
    }
    std::vector<float> edgeData = buildEdgeBuffer(triVerts);
    edgeVertexCount_ = edgeData.size()/3;
    if(!edgeVbo_) glGenBuffers(1,&edgeVbo_);
    if(!edgeVao_) glGenVertexArrays(1,&edgeVao_);
    glBindVertexArray(edgeVao_);glBindBuffer(GL_ARRAY_BUFFER,edgeVbo_);
    glBufferData(GL_ARRAY_BUFFER,edgeData.size()*sizeof(float),edgeData.empty()?nullptr:edgeData.data(),GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glBindVertexArray(0);

    std::vector<float> lineData; lineData.reserve(lineVerts.size()*3);
    for (const auto& p : lineVerts) lineData.insert(lineData.end(), {p.x, p.y, p.z});
    wireVertexCount_ = lineData.size() / 3;
    if (!wireVbo_) glGenBuffers(1, &wireVbo_);
    if (!wireVao_) glGenVertexArrays(1, &wireVao_);
    glBindVertexArray(wireVao_);
    glBindBuffer(GL_ARRAY_BUFFER, wireVbo_);
    glBufferData(GL_ARRAY_BUFFER, lineData.size()*sizeof(float), lineData.empty()?nullptr:lineData.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glBindVertexArray(0);

    fit();
    return (vertexCount_ + wireVertexCount_) > 0;
}

void Renderer3D::setSectionPlane(int axis, float fraction) {
    fraction = std::max(-1.0f, std::min(1.0f, fraction));
    Vec3 n{0,0,1};
    if (axis == 0) n = {1,0,0}; else if (axis == 1) n = {0,1,0}; else n = {0,0,1};
    sectionNormal_ = n;
    const float centerAlongAxis = axis==0?center_.x:(axis==1?center_.y:center_.z);
    sectionD_ = centerAlongAxis + fraction * radius_;
}

void Renderer3D::draw(){
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    if(!vertexCount_&&!wireVertexCount_)return;
    Mat4 rot = mul(rotX(pitch_), rotY(yaw_));
    Mat4 v=translate(0,0,-distance_); v=mul(v,rot); v=mul(v,translate(-center_.x,-center_.y,-center_.z));
    Mat4 mvp=mul(projection_,v);
    if(vertexCount_){
        if (wireframeMode_ && edgeVertexCount_) {
            // Tel kafes modu: dolu ucgen yerine kenar (GL_LINES) cizilir,
            // ayni wire shader (golgelendirme YOK, sadece kesit destegi).
            glUseProgram(wireProgram_);
            glUniformMatrix4fv(glGetUniformLocation(wireProgram_,"uMVP"),1,GL_FALSE,mvp.m);
            glUniform1i(glGetUniformLocation(wireProgram_,"uSectionEnabled"), sectionEnabled_?1:0);
            glUniform3f(glGetUniformLocation(wireProgram_,"uSectionNormal"), sectionNormal_.x, sectionNormal_.y, sectionNormal_.z);
            glUniform1f(glGetUniformLocation(wireProgram_,"uSectionD"), sectionD_);
            glBindVertexArray(edgeVao_);glDrawArrays(GL_LINES,0,(GLsizei)edgeVertexCount_);glBindVertexArray(0);
        } else {
            glUseProgram(program_);
            glUniformMatrix4fv(glGetUniformLocation(program_,"uMVP"),1,GL_FALSE,mvp.m);
            glUniformMatrix4fv(glGetUniformLocation(program_,"uViewRot"),1,GL_FALSE,rot.m);
            glUniform1i(glGetUniformLocation(program_,"uSectionEnabled"), sectionEnabled_?1:0);
            glUniform3f(glGetUniformLocation(program_,"uSectionNormal"), sectionNormal_.x, sectionNormal_.y, sectionNormal_.z);
            glUniform1f(glGetUniformLocation(program_,"uSectionD"), sectionD_);
            glBindVertexArray(vao_);glDrawArrays(GL_TRIANGLES,0,(GLsizei)vertexCount_);glBindVertexArray(0);
        }
    }
    if(wireVertexCount_){
        glUseProgram(wireProgram_);
        glUniformMatrix4fv(glGetUniformLocation(wireProgram_,"uMVP"),1,GL_FALSE,mvp.m);
        glUniform1i(glGetUniformLocation(wireProgram_,"uSectionEnabled"), sectionEnabled_?1:0);
        glUniform3f(glGetUniformLocation(wireProgram_,"uSectionNormal"), sectionNormal_.x, sectionNormal_.y, sectionNormal_.z);
        glUniform1f(glGetUniformLocation(wireProgram_,"uSectionD"), sectionD_);
        glBindVertexArray(wireVao_);glDrawArrays(GL_LINES,0,(GLsizei)wireVertexCount_);glBindVertexArray(0);
    }
    if(measureCount_>0){
        glUseProgram(overlayProgram_);glUniformMatrix4fv(glGetUniformLocation(overlayProgram_,"uMVP"),1,GL_FALSE,mvp.m);glBindVertexArray(overlayVao_);glBindBuffer(GL_ARRAY_BUFFER,overlayVbo_);glBufferData(GL_ARRAY_BUFFER,measureCount_*3*sizeof(float),measure_,GL_DYNAMIC_DRAW);glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vec3),(void*)0);glDrawArrays(GL_POINTS,0,measureCount_);if(measureCount_>=2)glDrawArrays(GL_LINE_STRIP,0,measureCount_);
        for(const auto& h:history_){ if(h.empty()) continue; glBufferData(GL_ARRAY_BUFFER,h.size()*sizeof(Vec3),h.data(),GL_DYNAMIC_DRAW); glDrawArrays(GL_POINTS,0,(GLsizei)h.size()); if(h.size()>=2){ if(h.size()==3) glDrawArrays(GL_LINE_STRIP,0,3); else glDrawArrays(GL_LINE_STRIP,0,(GLsizei)h.size()); }}
        glBindVertexArray(0);
    }
}
void Renderer3D::setMeasurementPoints(const Vec3* points,int count){measureCount_=std::max(0,std::min(3,count));for(int i=0;i<measureCount_;++i)measure_[i]=points[i];}
void Renderer3D::setMeasurementHistory(const std::vector<std::vector<Vec3>>& history){history_=history;}
void Renderer3D::clearMeasurementOverlay(){measureCount_=0;history_.clear();}
void Renderer3D::clear(){if(overlayVbo_)glDeleteBuffers(1,&overlayVbo_);if(overlayVao_)glDeleteVertexArrays(1,&overlayVao_);if(overlayProgram_)glDeleteProgram(overlayProgram_);if(vbo_)glDeleteBuffers(1,&vbo_);if(vao_)glDeleteVertexArrays(1,&vao_);if(program_)glDeleteProgram(program_);if(wireVbo_)glDeleteBuffers(1,&wireVbo_);if(wireVao_)glDeleteVertexArrays(1,&wireVao_);if(wireProgram_)glDeleteProgram(wireProgram_);if(edgeVbo_)glDeleteBuffers(1,&edgeVbo_);if(edgeVao_)glDeleteVertexArrays(1,&edgeVao_);vbo_=vao_=program_=wireVbo_=wireVao_=wireProgram_=edgeVbo_=edgeVao_=0;vertexCount_=0;wireVertexCount_=0;edgeVertexCount_=0;sectionEnabled_=false;boundsMin_=boundsMax_=Vec3{};}

Ray Renderer3D::screenRay(float x,float y) const {
    float nx=(2.0f*x/(float)width_-1.0f), ny=(1.0f-2.0f*y/(float)height_);
    float fovy=45.0f*3.14159265f/180.0f; float aspect=(float)width_/(float)height_;
    Vec3 forward{0,0,-1};
    float cy=std::cos(yaw_), sy=std::sin(yaw_), cp=std::cos(pitch_), sp=std::sin(pitch_);
    forward={sy*cp,-sp,-cy*cp};
    Vec3 right{cy,0,sy}; Vec3 up{-sy*sp,cp,cy*sp};
    float k=std::tan(fovy*.5f); Vec3 dir=forward + right*(nx*aspect*k) + up*(ny*k);
    float l=length(dir); if(l>1e-6f) dir=dir*(1.0f/l);
    Vec3 origin=center_ - forward*distance_; return {origin,dir};
}


bool Renderer3D::projectToScreen(const Vec3& world,float& x,float& y,float& depth) const {
    Mat4 v=translate(0,0,-distance_); v=mul(v,rotX(pitch_)); v=mul(v,rotY(yaw_)); v=mul(v,translate(-center_.x,-center_.y,-center_.z)); Mat4 mvp=mul(projection_,v);
    const float* a=mvp.m; float cx=a[0]*world.x+a[4]*world.y+a[8]*world.z+a[12]; float cy=a[1]*world.x+a[5]*world.y+a[9]*world.z+a[13]; float cz=a[2]*world.x+a[6]*world.y+a[10]*world.z+a[14]; float cw=a[3]*world.x+a[7]*world.y+a[11]*world.z+a[15];
    if(cw<=1e-6f) return false; float nx=cx/cw, ny=cy/cw; depth=cz/cw; if(nx<-1||nx>1||ny<-1||ny>1||depth<-1||depth>1) return false; x=(nx*.5f+.5f)*width_; y=(1.f-(ny*.5f+.5f))*height_; return true;
}
