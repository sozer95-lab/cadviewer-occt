#pragma once
#include <GLES3/gl3.h>
#include <vector>
#include "../core/Mat4.h"
#include "../geometry/Mesh.h"
#include "../core/Vec3.h"
#include "../geometry/Ray.h"
class Renderer3D {
    GLuint program_=0,vbo_=0,vao_=0; GLuint overlayProgram_=0,overlayVbo_=0,overlayVao_=0; int width_=1,height_=1; float yaw_=0,pitch_=0,distance_=5; Vec3 center_{}; float radius_=1; Mat4 projection_; size_t vertexCount_=0;
    GLuint wireProgram_=0,wireVbo_=0,wireVao_=0; size_t wireVertexCount_=0; // DWG/DXF cizgi verisi (GL_LINES) icin ayri program+arabellek
    GLuint edgeVbo_=0,edgeVao_=0; size_t edgeVertexCount_=0; bool wireframeMode_=false; // ana ucgen mesh icin tel-kafes GORUNUM (ayri gecici) - DWG'nin kendi cizgi verisinden FARKLI
    Vec3 boundsMin_{}, boundsMax_{}; // GERCEK sinir kutusu (kure DEGIL) - parca boyutu (X x Y x Z) icin
    void updateProjection();
    Vec3 measure_[3]{}; int measureCount_=0; std::vector<std::vector<Vec3>> history_;
    // Kesit (section/clipping plane) durumu: dunya uzayinda dot(N,P)=D
    // denklemiyle tanimli bir duzlem; P.N > D olan parcalar KIRPILIR
    // (fragment shader'da discard edilir). Sadece ana ucgen mesh VE DWG
    // cizgi geometrisi kirpilir; olcum overlay'i (noktalar/cizgiler) BILEREK
    // kirpilmaz - kullanici bir olcum noktasi koyup sonra o noktayi kesip
    // gecerse, isaretcinin BEKLENMEDIK sekilde kaybolmasi kafa karistirici
    // olurdu.
    bool sectionEnabled_=false; Vec3 sectionNormal_{0,0,1}; float sectionD_=0;
public:
    void init(); void resize(int w,int h); void draw();
    void setMeasurementPoints(const Vec3* points,int count); void setMeasurementHistory(const std::vector<std::vector<Vec3>>& history); void clearMeasurementOverlay();
    void orbit(float dx,float dy); void zoom(float delta); void fit(); void home();
    bool setMesh(const MeshData& mesh);
    // DWG/DXF icin: hem ucgen (3DFACE) hem cizgi (LINE/ARC/CIRCLE/POLYLINE)
    // verisini AYNI ANDA yukler ve ORTAK bir sinir kutusu (bounding box)
    // hesaplayip kamerayi ona gore konumlandirir (fit). triVerts/lineVerts
    // bos olabilir (ornegin sadece cizgilerden olusan bir 2D DWG ciziminde
    // triVerts bos kalir).
    bool setDwgGeometry(const std::vector<Vec3>& triVerts, const std::vector<Vec3>& lineVerts);
    Ray screenRay(float x,float y) const; bool projectToScreen(const Vec3& world,float& x,float& y,float& depth) const; bool hasMesh()const{return vertexCount_>0||wireVertexCount_>0;} void clear();
    // Sahnenin sinir kuresi yaricapi/merkezi - cizgi tabanli (DWG) picking
    // toleransi VE kesit duzlemi konumlandirmasi icin kullanilir.
    float boundingRadius() const { return radius_; }
    Vec3 boundingCenter() const { return center_; }
    // GERCEK eksen-hizali sinir kutusu boyutu (X,Y,Z genislik) - parca
    // boyutu gosterimi icin. Model yuklu degilse {0,0,0}.
    Vec3 boundingSize() const { return hasMesh() ? (boundsMax_ - boundsMin_) : Vec3{}; }
    // axis: 0=X,1=Y,2=Z. fraction: -1..1, merkeze gore yaricap oraninda
    // kaydirma (0 = tam merkezden gecen duzlem). Duzlem normali secilen
    // eksen yonunu gosterir; P.N > D olan taraf KESILIR (gizlenir).
    void setSectionPlane(int axis, float fraction);
    void setSectionEnabled(bool enabled) { sectionEnabled_ = enabled; }
    bool sectionEnabled() const { return sectionEnabled_; }
    // Test/dogrulama amacli: kesit duzleminin GERCEK dunya-uzayi parametreleri.
    Vec3 sectionNormal() const { return sectionNormal_; }
    float sectionD() const { return sectionD_; }
    // Ana ucgen mesh'i (STL/OBJ/STEP/IGES/3DFACE) DOLU yuzey yerine TEL
    // KAFES (kenarlar) olarak cizer - is parcasinin ic gecislerini/kenar
    // sayisini incelemek icin. DWG'nin kendi cizgi geometrisi (LINE/ARC/vb,
    // wireVao_) bu ayardan ETKILENMEZ, o zaten her zaman cizgi olarak cizilir.
    void setWireframeMode(bool enabled) { wireframeMode_ = enabled; }
    bool wireframeMode() const { return wireframeMode_; }
};
