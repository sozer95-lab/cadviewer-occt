#pragma once
#include "../core/Vec3.h"
#include <string>
#include <vector>
enum class MeasurementType { None,Distance,Angle,Radius,Diameter,Area,Volume };
struct MeasurementResult { bool valid=false; double value=0; std::string unit; };
struct CompletedMeasurement { MeasurementType type=MeasurementType::None; Vec3 p[3]{}; int count=0; MeasurementResult result{}; };
class MeasurementManager {
    MeasurementType type_=MeasurementType::None; Vec3 p_[3]{}; int n_=0; MeasurementResult r_{};
    std::vector<CompletedMeasurement> history_;
public:
    void begin(MeasurementType t){type_=t;n_=0;r_={};}
    // Starts a fresh measurement while keeping the selected mode active.
    void restart(){n_=0;r_={};}
    void clear(){type_=MeasurementType::None;n_=0;r_={};history_.clear();}
    void clearHistory(){history_.clear();}
    bool removeLast(){ if(history_.empty()) return false; history_.pop_back(); return true; }
    const std::vector<CompletedMeasurement>& history() const{return history_;}
    bool addPoint(const Vec3&);
    MeasurementType type() const{return type_;}
    int pointCount() const{return n_;}
    int requiredPoints() const{return type_==MeasurementType::Angle?3:type_==MeasurementType::Distance?2:0;}
    const Vec3& point(int i) const{return p_[i];}
    const MeasurementResult& result()const{return r_;}
};

// 2.3.0: label snapshot for completed measurements.
struct MeasurementLabelSnapshot { std::string text; Vec3 anchor{}; bool valid=false; };
inline MeasurementLabelSnapshot measurementLabelFor(const CompletedMeasurement& m){
    MeasurementLabelSnapshot s; if(!m.result.valid) return s;
    if(m.type==MeasurementType::Distance) s.anchor=(m.p[0]+m.p[1])*0.5f;
    else if(m.type==MeasurementType::Angle) s.anchor=m.p[1];
    else return s;
    s.text=std::to_string(m.result.value)+" "+m.result.unit; s.valid=true; return s;
}
