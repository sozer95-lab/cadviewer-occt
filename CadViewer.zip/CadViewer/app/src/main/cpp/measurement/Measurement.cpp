#include "Measurement.h"
#include <cmath>
bool MeasurementManager::addPoint(const Vec3&p){if(type_==MeasurementType::None)return false;
    if(r_.valid && n_>=requiredPoints()){ restart(); }
    if(n_>=3)return false;p_[n_++]=p;if(type_==MeasurementType::Distance&&n_==2){r_={true,length(p_[1]-p_[0]),"model"}; history_.push_back({type_,{p_[0],p_[1],{}},2,r_}); return true;}if(type_==MeasurementType::Angle&&n_==3){Vec3 a=p_[0]-p_[1],b=p_[2]-p_[1];float d=length(a)*length(b);if(d>1e-6f){float c=dot(a,b)/d;c=std::fmax(-1.f,std::fmin(1.f,c));r_={true,std::acos(c)*180.0/M_PI,"deg"}; history_.push_back({type_,{p_[0],p_[1],p_[2]},3,r_});}return true;}return false;}
