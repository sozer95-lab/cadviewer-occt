#pragma once
#include <cstddef>

extern "C" {

struct FfiPoint3 { float x, y, z; };

struct DwgLoadResult {
    int ok;
    char* error_message;
    FfiPoint3* line_points;
    size_t line_point_count;
    FfiPoint3* tri_points;
    size_t tri_point_count;
    int unsupported_solid_count;
};

DwgLoadResult dwg_load(const char* path);
void dwg_free(DwgLoadResult result);

}
