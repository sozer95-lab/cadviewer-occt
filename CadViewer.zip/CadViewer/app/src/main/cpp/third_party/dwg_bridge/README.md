# dwg_bridge ARM64 runtime slot

Buraya, `.github/workflows/build-dwg-android.yml` iş akışının ürettiği
`libdwg_bridge.a` (Android ARM64, statik kütüphane) yerleştirilir.

OCCT'den farklı olarak bu **opsiyonel değildir** — `dwg_bridge` (Rust,
`acadrust` kütüphanesi üzerine ince bir FFI katmanı) **MIT lisanslıdır**,
bu yüzden proje her zaman bu kütüphaneyi bağlamaya hazır tutulur
(`CMakeLists.txt`'de `if(CADVIEWER_HAS_OCCT)` gibi bir koşula bağlı DEĞİLDİR).

## Nasıl üretilir

1. GitHub'daki bu depoda **Actions** → **"DWG/DXF Rust köprüsü Android ARM64 derlemesi"**
2. **Run workflow**
3. ~5-10 dakika sonra (Rust derlemesi OCCT'den çok daha hızlıdır) **Artifacts**
   bölümünden `dwg-bridge-android-arm64.zip`'i indirin
4. İçindeki `libdwg_bridge.a` dosyasını bu klasöre (`arm64-v8a/` alt klasörü
   içine) kopyalayın

## Kapsam ve sınırlar

`dwg_bridge`, DWG/DXF dosyalarından şu varlıkları render edilebilir
geometriye çevirir:
- **LINE, CIRCLE, ARC** — çizgi segmentlerine (tessellate edilmiş) çevrilir
- **LWPOLYLINE, POLYLINE3D** — vertex zinciri, çizgi segmentleri olarak
- **3DFACE** — gerçek üçgen/dörtgen yüzey verisi (GERÇEK 3D geometri)

**ACIS/SAT tabanlı 3D katılar (3DSOLID, BODY, REGION) SAYILIR ama
geometriye ÇEVRİLMEZ.** Bu veri, DWG içinde ayrı bir format (ACIS) olarak
gömülüdür; render edilebilir bir hale getirmek (tessellation) ayrı, çok
daha büyük bir geometri kernel'i entegrasyonu gerektirir (SAT B-rep
verisinin OCCT'nin `TopoDS_Shape`'ine aktarılıp OCCT'nin kendi tessellation
motoruyla işlenmesi gibi) — bu, gelecekteki bir çalışma konusudur.

`LWPOLYLINE`'daki **bulge (yay) segmentleri gerçek yay olarak tessellate
edilir** (DXF standardına göre: pozitif bulge = yürüyüş yönüne göre sağa
büker; bu, geliştirme sırasında gerçek DXF dokümantasyonu araştırılarak
doğrulandı, tahmin edilmedi — 6/6 Rust testiyle sınandı).

## Mühendislik notu (ACIS/wireframe kararı)

`acadrust`'ın ACIS modülü, SAT B-rep verisinin **tamamını** (body/face/loop/
coedge/edge/vertex topolojisi + düzlem/koni/küre/simit/NURBS yüzey
parametreleri) yapılandırılmış olarak sunar — teorik olarak bunu OCCT'nin
`TopoDS_Shape`'ine aktarıp tam dolu-yüzey render + hacim hesaplama mümkündür.
**Bu, haftalar sürebilecek ayrı bir geometri kernel projesi olduğu için bu
sürüme dahil edilmedi.**

Bunun yerine, `Solid3D` entity'sinin genelde birlikte taşıdığı **hazır
wireframe verisi** (`Solid3D.wires`, AutoCAD'in görüntüleme için önceden
hesapladığı kenar çizgileri) kullanıldı — bu, tam B-rep yeniden inşasına
gerek kalmadan katının **gerçek şeklini** (tel kafes olarak) gösterir. Bu
karar, host'ta gerçek birim testleriyle doğrulandı (`cargo test`,
`dwg_bridge/src/lib.rs` içindeki `tests` modülü): wireframe verisi olan bir
`Solid3D` doğru çizgi segmentlerine çevrilirken, wireframe verisi olmayan
bir `Solid3D` doğru şekilde "desteklenmeyen" olarak sayılıyor.
