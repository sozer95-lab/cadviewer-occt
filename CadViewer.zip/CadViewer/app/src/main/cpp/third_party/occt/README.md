# OCCT ARM64 runtime slot

DOLU — gercek OCCT ARM64 derlemesi 2026-09-05'te GitHub Actions ile
(.github/workflows/build-occt-android.yml) uretilip buraya yerlestirildi.
`app/build.gradle.kts` icinde -DCADVIEWER_HAS_OCCT=1 bayragi ACIKTIR.

Kullanilan 15 kutuphane (host'ta gercek header'lar + .so'larla sembol
duzeyinde dogrulandi, sifir eksik bagimlilik):

- arm64-v8a/libTKernel.so
- arm64-v8a/libTKMath.so
- arm64-v8a/libTKG2d.so
- arm64-v8a/libTKG3d.so
- arm64-v8a/libTKGeomBase.so
- arm64-v8a/libTKBRep.so
- arm64-v8a/libTKTopAlgo.so
- arm64-v8a/libTKGeomAlgo.so
- arm64-v8a/libTKMesh.so
- arm64-v8a/libTKXSBase.so
- arm64-v8a/libTKDE.so
- arm64-v8a/libTKDESTEP.so
- arm64-v8a/libTKDEIGES.so
- arm64-v8a/libTKLCAF.so   (XDE/Application Framework - sonradan eklendi)
- arm64-v8a/libTKXCAF.so   (XDE/Application Framework - sonradan eklendi)

Not: Bu klasorde ayrica derleme sirasinda uretilen ~48 .so dosyasinin
TAMAMI da bulunur (OCCT'nin kendi ic bagimliliklari nedeniyle daha fazla
kutuphane derlenir); yukaridaki 15'i CadViewer'in CMakeLists.txt'sinde
ACIKCA baglanan, gercekten kullanilan alt kumedir.
