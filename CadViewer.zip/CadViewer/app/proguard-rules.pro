# Bu proje minifyEnabled=false ile derleniyor; kurallar aktif degil.
# Dosya, build.gradle.kts icindeki proguardFiles() referansinin bulabilmesi
# icin var olmak zorunda.
