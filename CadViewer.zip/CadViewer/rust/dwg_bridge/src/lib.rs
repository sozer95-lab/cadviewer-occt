//! dwg_bridge — acadrust'i (MIT lisansli, saf Rust DWG/DXF okuyucu) C/C++'a
//! C ABI uzerinden acan ince bir katman.
//!
//! Kapsam (bilerek sinirli, KURULUM.md'de aciklanir):
//!   - 2D/3D CIZGI TABANLI varliklar (LINE, CIRCLE, ARC, LWPOLYLINE,
//!     POLYLINE3D) -> cizgi segmentlerine (tessellate edilmis) donusturulur.
//!   - 3DFACE -> gercek ucgen/dortgen yuzey verisine donusturulur (GERCEK 3D
//!     geometri, ACIS gerektirmez).
//!   - 3DSOLID/BODY/REGION (ACIS/SAT govdeler) -> SADECE SAYILIR, geometriye
//!     CEVRILMEZ. Bu, SAT B-rep verisinin (NURBS yuzeyler/egriler) render
//!     edilebilir bir uçgen agina donusturulmesinin (tessellation) ayri,
//!     cok daha buyuk bir geometri kernel'i isi olmasindandir - OCCT'nin
//!     BRepMesh_IncrementalMesh'inin yaptigi is budur ve bu kapsamin
//!     DISINDADIR (bkz. KURULUM.md, "DWG - ACIS siniri").

use acadrust::entities::EntityType;
use acadrust::io::dwg::DwgReader;
use acadrust::{CadDocument, DxfReader};
use std::ffi::{c_char, c_float, CStr};
use std::os::raw::c_int;
use std::path::Path;

#[repr(C)]
pub struct FfiPoint3 {
    pub x: c_float,
    pub y: c_float,
    pub z: c_float,
}

/// dwg_load()'un sonucu. Bellek Rust tarafinda ayrilir; cagiran taraf
/// (C++) bitirdiginde MUTLAKA dwg_free() cagirmalidir - aksi halde bellek
/// sizintisi olur (Rust'in kendi allocator'i kullanildigi icin C++
/// tarafinin dogrudan free() cagirmasi GUVENLI DEGILDIR).
#[repr(C)]
pub struct DwgLoadResult {
    pub ok: c_int,
    pub error_message: *mut c_char,
    /// Cizgi segmentleri: her 2 ardisik nokta bir segmenttir (GL_LINES).
    pub line_points: *mut FfiPoint3,
    pub line_point_count: usize,
    /// Ucgen koseleri: her 3 ardisik nokta bir ucgendir (GL_TRIANGLES).
    pub tri_points: *mut FfiPoint3,
    pub tri_point_count: usize,
    /// Geometriye cevrilemeyen ACIS tabanli 3D govde sayisi (3DSOLID/BODY/REGION).
    pub unsupported_solid_count: c_int,
}

fn error_result(msg: &str) -> DwgLoadResult {
    let c_msg = std::ffi::CString::new(msg).unwrap_or_default();
    DwgLoadResult {
        ok: 0,
        error_message: c_msg.into_raw(),
        line_points: std::ptr::null_mut(),
        line_point_count: 0,
        tri_points: std::ptr::null_mut(),
        tri_point_count: 0,
        unsupported_solid_count: 0,
    }
}

fn tessellate_arc(center: (f64, f64, f64), radius: f64, start_deg: f64, end_deg: f64, segments: usize, out: &mut Vec<FfiPoint3>) {
    let start = start_deg.to_radians();
    let mut end = end_deg.to_radians();
    if end <= start {
        end += std::f64::consts::TAU;
    }
    let step = (end - start) / segments as f64;
    let mut prev: Option<(f64, f64)> = None;
    for i in 0..=segments {
        let a = start + step * i as f64;
        let x = center.0 + radius * a.cos();
        let y = center.1 + radius * a.sin();
        if let Some((px, py)) = prev {
            out.push(FfiPoint3 { x: px as c_float, y: py as c_float, z: center.2 as c_float });
            out.push(FfiPoint3 { x: x as c_float, y: y as c_float, z: center.2 as c_float });
        }
        prev = Some((x, y));
    }
}

// LWPOLYLINE'daki bulge (yay) segmentlerini tessellate eder. DXF/AutoCAD
// bulge tanimi: bulge = tan(theta/4), theta = yayin merkez acisi (isaretli:
// pozitif=saat yonu tersi/CCW, negatif=saat yonu/CW). Asagidaki formuller
// host'ta GERCEK testlerle (yari cember ve ceyrek cember, elle hesaplanmis
// beklenen merkez/yaricap degerleriyle) dogrulanmistir:
//   theta = 4*atan(bulge)
//   d = |B-A| (kiris uzunlugu)
//   r_signed = d / (2*sin(theta/2))
//   M = (A+B)/2, u = normalize(B-A), perp = rotate90_ccw(u)
//   C = M + perp * r_signed * cos(theta/2)   [yayin GERCEK merkezi]
//   angleA = atan2(A-C), sonra angleA'dan angleA+theta'ya kadar tessellate.
// bulge == 0 ise (duz cizgi), bu fonksiyon CAGRILMAZ - caller duz segment ekler.
fn tessellate_bulge_segment(a: (f64, f64), b: (f64, f64), bulge: f64, segments: usize, out: &mut Vec<FfiPoint3>) {
    let theta = 4.0 * bulge.atan();
    let d = ((b.0 - a.0).powi(2) + (b.1 - a.1).powi(2)).sqrt();
    if d < 1e-9 || theta.abs() < 1e-9 {
        out.push(FfiPoint3 { x: a.0 as c_float, y: a.1 as c_float, z: 0.0 });
        out.push(FfiPoint3 { x: b.0 as c_float, y: b.1 as c_float, z: 0.0 });
        return;
    }
    let r_signed = d / (2.0 * (theta / 2.0).sin());
    let mx = (a.0 + b.0) / 2.0;
    let my = (a.1 + b.1) / 2.0;
    let ux = (b.0 - a.0) / d;
    let uy = (b.1 - a.1) / d;
    let perp_x = -uy;
    let perp_y = ux;
    let offset = r_signed * (theta / 2.0).cos();
    let cx = mx + perp_x * offset;
    let cy = my + perp_y * offset;
    let radius = r_signed.abs();
    let angle_a = (a.1 - cy).atan2(a.0 - cx);
    let mut prev: Option<(f64, f64)> = None;
    for i in 0..=segments {
        let t = i as f64 / segments as f64;
        let angle = angle_a + theta * t;
        let x = cx + radius * angle.cos();
        let y = cy + radius * angle.sin();
        if let Some((px, py)) = prev {
            out.push(FfiPoint3 { x: px as c_float, y: py as c_float, z: 0.0 });
            out.push(FfiPoint3 { x: x as c_float, y: y as c_float, z: 0.0 });
        }
        prev = Some((x, y));
    }
}

fn extract_geometry(doc: &CadDocument) -> (Vec<FfiPoint3>, Vec<FfiPoint3>, i32) {
    let mut lines: Vec<FfiPoint3> = Vec::new();
    let mut tris: Vec<FfiPoint3> = Vec::new();
    let mut unsupported = 0i32;
    const CIRCLE_SEGMENTS: usize = 48;

    for entity in doc.entities() {
        match entity {
            EntityType::Line(l) => {
                lines.push(FfiPoint3 { x: l.start.x as c_float, y: l.start.y as c_float, z: l.start.z as c_float });
                lines.push(FfiPoint3 { x: l.end.x as c_float, y: l.end.y as c_float, z: l.end.z as c_float });
            }
            EntityType::Circle(c) => {
                tessellate_arc((c.center.x, c.center.y, c.center.z), c.radius, 0.0, 360.0, CIRCLE_SEGMENTS, &mut lines);
            }
            EntityType::Arc(a) => {
                tessellate_arc(
                    (a.center.x, a.center.y, a.center.z),
                    a.radius,
                    a.start_angle.to_degrees(),
                    a.end_angle.to_degrees(),
                    CIRCLE_SEGMENTS / 2,
                    &mut lines,
                );
            }
            EntityType::LwPolyline(p) => {
                let n = p.vertices.len();
                if n >= 2 {
                    let last = if p.is_closed { n } else { n - 1 };
                    const BULGE_SEGMENTS: usize = 16;
                    for i in 0..last {
                        let a = p.vertices[i];
                        let b = p.vertices[(i + 1) % n];
                        if a.bulge.abs() > 1e-9 {
                            tessellate_bulge_segment(
                                (a.location.x, a.location.y),
                                (b.location.x, b.location.y),
                                a.bulge,
                                BULGE_SEGMENTS,
                                &mut lines,
                            );
                        } else {
                            lines.push(FfiPoint3 { x: a.location.x as c_float, y: a.location.y as c_float, z: 0.0 });
                            lines.push(FfiPoint3 { x: b.location.x as c_float, y: b.location.y as c_float, z: 0.0 });
                        }
                    }
                }
            }
            EntityType::Polyline3D(p) => {
                let n = p.vertices.len();
                if n >= 2 {
                    let last = if p.flags.closed { n } else { n - 1 };
                    for i in 0..last {
                        let a = &p.vertices[i];
                        let b = &p.vertices[(i + 1) % n];
                        lines.push(FfiPoint3 { x: a.position.x as c_float, y: a.position.y as c_float, z: a.position.z as c_float });
                        lines.push(FfiPoint3 { x: b.position.x as c_float, y: b.position.y as c_float, z: b.position.z as c_float });
                    }
                }
            }
            EntityType::Face3D(f) => {
                let p1 = FfiPoint3 { x: f.first_corner.x as c_float, y: f.first_corner.y as c_float, z: f.first_corner.z as c_float };
                let p2 = FfiPoint3 { x: f.second_corner.x as c_float, y: f.second_corner.y as c_float, z: f.second_corner.z as c_float };
                let p3 = FfiPoint3 { x: f.third_corner.x as c_float, y: f.third_corner.y as c_float, z: f.third_corner.z as c_float };
                let p4 = FfiPoint3 { x: f.fourth_corner.x as c_float, y: f.fourth_corner.y as c_float, z: f.fourth_corner.z as c_float };
                tris.push(FfiPoint3 { x: p1.x, y: p1.y, z: p1.z });
                tris.push(FfiPoint3 { x: p2.x, y: p2.y, z: p2.z });
                tris.push(FfiPoint3 { x: p3.x, y: p3.y, z: p3.z });
                let farkli = (f.third_corner.x - f.fourth_corner.x).abs() > 1e-9
                    || (f.third_corner.y - f.fourth_corner.y).abs() > 1e-9
                    || (f.third_corner.z - f.fourth_corner.z).abs() > 1e-9;
                if farkli {
                    tris.push(FfiPoint3 { x: p1.x, y: p1.y, z: p1.z });
                    tris.push(FfiPoint3 { x: p3.x, y: p3.y, z: p3.z });
                    tris.push(FfiPoint3 { x: p4.x, y: p4.y, z: p4.z });
                }
            }
            EntityType::Solid3D(s) => {
                // ONCE hazir tel kafes (wireframe) verisini dene - AutoCAD
                // genelde katinin kenar cizgilerini GORUNTULEME icin ayrica
                // saklar (Solid3D.wires), TAM ACIS/SAT B-rep ayristirmasi
                // GEREKMEDEN. Bu veri VARSA, katinin GERCEK 3D seklini
                // (tel kafes olarak - dolu yuzey degil) gosterebiliriz.
                let mut had_wires = false;
                for wire in &s.wires {
                    let n = wire.points.len();
                    if n < 2 { continue; }
                    had_wires = true;
                    for i in 0..n.saturating_sub(1) {
                        let a = &wire.points[i];
                        let b = &wire.points[i + 1];
                        lines.push(FfiPoint3 { x: a.x as c_float, y: a.y as c_float, z: a.z as c_float });
                        lines.push(FfiPoint3 { x: b.x as c_float, y: b.y as c_float, z: b.z as c_float });
                    }
                }
                // Wireframe verisi YOKSA (bazi DWG yazicilari bunu dahil
                // etmez): tam ACIS/SAT B-rep ayristirmasi bu surumde
                // YAPILMIYOR - SAYILIR ve kullaniciya bildirilir (bkz.
                // KURULUM.md, "DWG - ACIS siniri").
                if !had_wires {
                    unsupported += 1;
                }
            }
            _ => {}
        }
    }
    (lines, tris, unsupported)
}

fn load_internal(path: &str) -> Result<CadDocument, String> {
    let ext = Path::new(path)
        .extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_lowercase())
        .unwrap_or_default();
    if ext == "dxf" {
        DxfReader::from_file(path)
            .map_err(|e| format!("DXF acilamadi: {e}"))?
            .read()
            .map_err(|e| format!("DXF okuma hatasi: {e}"))
    } else if ext == "dwg" {
        let mut reader = DwgReader::from_file(path).map_err(|e| format!("DWG acilamadi: {e}"))?;
        reader.read().map_err(|e| format!("DWG okuma hatasi: {e}"))
    } else {
        Err(format!("Desteklenmeyen uzanti: .{ext} (beklenen .dwg veya .dxf)"))
    }
}

/// # Safety
/// `path` gecerli, NUL sonlandirilmis bir UTF-8 C string'i olmalidir.
#[no_mangle]
pub unsafe extern "C" fn dwg_load(path: *const c_char) -> DwgLoadResult {
    if path.is_null() {
        return error_result("path NULL");
    }
    let path_str = match CStr::from_ptr(path).to_str() {
        Ok(s) => s,
        Err(_) => return error_result("path gecersiz UTF-8"),
    };
    let doc = match load_internal(path_str) {
        Ok(d) => d,
        Err(e) => return error_result(&e),
    };
    let (mut lines, mut tris, unsupported) = extract_geometry(&doc);
    let line_point_count = lines.len();
    let tri_point_count = tris.len();
    let line_points = if line_point_count > 0 { lines.as_mut_ptr() } else { std::ptr::null_mut() };
    let tri_points = if tri_point_count > 0 { tris.as_mut_ptr() } else { std::ptr::null_mut() };
    std::mem::forget(lines);
    std::mem::forget(tris);
    DwgLoadResult {
        ok: 1,
        error_message: std::ptr::null_mut(),
        line_points,
        line_point_count,
        tri_points,
        tri_point_count,
        unsupported_solid_count: unsupported,
    }
}

/// `dwg_load()`'un dondurdugu tum belleği serbest birakir. Her sonuc icin
/// TAM OLARAK BIR KEZ cagrilmalidir.
#[no_mangle]
pub unsafe extern "C" fn dwg_free(result: DwgLoadResult) {
    if !result.error_message.is_null() {
        drop(std::ffi::CString::from_raw(result.error_message));
    }
    if !result.line_points.is_null() && result.line_point_count > 0 {
        drop(Vec::from_raw_parts(result.line_points, result.line_point_count, result.line_point_count));
    }
    if !result.tri_points.is_null() && result.tri_point_count > 0 {
        drop(Vec::from_raw_parts(result.tri_points, result.tri_point_count, result.tri_point_count));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use acadrust::entities::solid3d::Wire;
    use acadrust::entities::Solid3D;
    use acadrust::types::Vector3;
    use acadrust::CadDocument;

    #[test]
    fn solid3d_wireframe_dogru_cizgiye_donusuyor() {
        let mut doc = CadDocument::new();
        let mut solid = Solid3D::default();
        // Kare (5 nokta, kapali dortgen) - 4 segment beklenir
        let kare = vec![
            Vector3 { x: 0.0, y: 0.0, z: 0.0 },
            Vector3 { x: 20.0, y: 0.0, z: 0.0 },
            Vector3 { x: 20.0, y: 20.0, z: 0.0 },
            Vector3 { x: 0.0, y: 20.0, z: 0.0 },
            Vector3 { x: 0.0, y: 0.0, z: 0.0 },
        ];
        solid.wires.push(Wire::from_points(kare));
        doc.add_entity(EntityType::Solid3D(solid)).unwrap();

        let (lines, tris, unsupported) = extract_geometry(&doc);
        assert_eq!(unsupported, 0, "wireframe verisi VARSA 'desteklenmeyen' sayilmamali");
        assert_eq!(lines.len(), 8, "4 segment = 8 nokta beklenir");
        assert_eq!(tris.len(), 0);
        // Ilk segment: (0,0,0) -> (20,0,0)
        assert!((lines[0].x - 0.0).abs() < 1e-6 && (lines[0].y - 0.0).abs() < 1e-6);
        assert!((lines[1].x - 20.0).abs() < 1e-6 && (lines[1].y - 0.0).abs() < 1e-6);
        // Son segment: (0,20,0) -> (0,0,0)
        assert!((lines[6].x - 0.0).abs() < 1e-6 && (lines[6].y - 20.0).abs() < 1e-6);
        assert!((lines[7].x - 0.0).abs() < 1e-6 && (lines[7].y - 0.0).abs() < 1e-6);
    }

    #[test]
    fn solid3d_wireframesiz_desteklenmeyen_sayilir() {
        let mut doc = CadDocument::new();
        let solid = Solid3D::default(); // wires bos
        doc.add_entity(EntityType::Solid3D(solid)).unwrap();

        let (lines, tris, unsupported) = extract_geometry(&doc);
        assert_eq!(unsupported, 1, "wireframe verisi YOKSA desteklenmeyen olarak sayilmali");
        assert_eq!(lines.len(), 0);
        assert_eq!(tris.len(), 0);
    }

    // Bulge = tan(theta/4). theta=180 (yari cember) icin bulge=tan(45)=1.0.
    // GERCEK DXF standardi (ezdxf dokumentasyonu, Autodesk forumu ile
    // dogrulandi): POZITIF bulge, A'dan B'ye YURUYUS YONUNE GORE SAGA
    // bombelenir. A=(0,0)->B=(10,0) icin yon +X'tir, "sag" taraf -Y'dir.
    // A=(0,0), B=(10,0), bulge=1.0 -> yari cember, merkez=(5,0), yaricap=5,
    // apex (yayin en uzak noktasi) (5,-5) OLMALIDIR (sezgisel "yukari"
    // beklentisi YANLIS cikti ilk denemede - bu, standart arastirmasiyla
    // DOGRULANDI, kod DEGIL test beklentisi duzeltildi).
    #[test]
    fn bulge_yari_cember_dogru_tessellate_ediliyor() {
        let mut out = Vec::new();
        tessellate_bulge_segment((0.0, 0.0), (10.0, 0.0), 1.0, 32, &mut out);
        assert_eq!(out.len(), 64, "32 segment = 64 nokta (32 cift) beklenir");
        // Ilk nokta A'ya (0,0) yakin olmali
        assert!((out[0].x - 0.0).abs() < 1e-3 && (out[0].y - 0.0).abs() < 1e-3, "ilk nokta A");
        // Son nokta B'ye (10,0) yakin olmali
        let son = out.last().unwrap();
        assert!((son.x - 10.0).abs() < 1e-3 && (son.y - 0.0).abs() < 1e-3, "son nokta B, gercek=({},{})", son.x, son.y);
        // Ortadaki nokta (apex) (5,-5)'e yakin olmali (DXF standardi: pozitif
        // bulge = yuruyus yonune gore SAG taraf)
        let orta = &out[out.len()/2];
        assert!((orta.x - 5.0).abs() < 0.1 && (orta.y - (-5.0)).abs() < 0.1, "apex (5,-5) civarinda (DXF: pozitif=sag), gercek=({},{})", orta.x, orta.y);
        // TUM noktalar merkez (5,0)'dan TAM 5.0 uzaklikta olmali (gercek cember uzerinde)
        for p in &out {
            let d = ((p.x - 5.0).powi(2) + (p.y - 0.0).powi(2)).sqrt();
            assert!((d - 5.0).abs() < 0.01, "nokta ({},{}) merkezden {} uzaklikta, 5.0 beklenirdi", p.x, p.y, d);
        }
    }

    // Ceyrek cember: theta=90 -> bulge=tan(22.5)=0.41421356.
    // A=(1,0), B=(0,1), CCW -> merkez (0,0), yaricap 1.
    #[test]
    fn bulge_ceyrek_cember_dogru_merkez_yaricap() {
        let bulge = (std::f64::consts::PI / 8.0).tan(); // tan(22.5 derece) = tan(pi/8)
        let mut out = Vec::new();
        tessellate_bulge_segment((1.0, 0.0), (0.0, 1.0), bulge, 16, &mut out);
        for p in &out {
            let d = ((p.x).powi(2) + (p.y).powi(2)).sqrt(); // merkez (0,0) varsayimi
            assert!((d - 1.0).abs() < 0.01, "nokta ({},{}) merkezden(0,0) {} uzaklikta, 1.0 beklenirdi", p.x, p.y, d);
        }
        let son = out.last().unwrap();
        assert!((son.x - 0.0).abs() < 1e-3 && (son.y - 1.0).abs() < 1e-3, "son nokta B=(0,1), gercek=({},{})", son.x, son.y);
    }

    // Negatif bulge (CW) - DXF standardina gore SOL tarafa (bu ornekte +Y'ye)
    // bombelenmelidir (pozitif bulge testinin TAM TERSI yon).
    #[test]
    fn bulge_negatif_ters_yonde_bukuluyor() {
        let mut out = Vec::new();
        tessellate_bulge_segment((0.0, 0.0), (10.0, 0.0), -1.0, 32, &mut out);
        let orta = &out[out.len()/2];
        assert!((orta.x - 5.0).abs() < 0.1 && (orta.y - 5.0).abs() < 0.1, "negatif bulge apex (5,5) civarinda (pozitifin tersi), gercek=({},{})", orta.x, orta.y);
    }

    // LWPOLYLINE entity'sinde bulge alaninin GERCEKTEN kullanildigini
    // (duz cizgiye degil, tessellate edilmis yaya donustugunu) dogrular.
    #[test]
    fn lwpolyline_bulge_entity_seviyesinde_tessellate_ediliyor() {
        use acadrust::entities::{LwPolyline, LwVertex};
        let mut doc = CadDocument::new();
        let mut poly = LwPolyline::default();
        let mut v0 = LwVertex::from_coords(0.0, 0.0);
        v0.bulge = 1.0; // yari cember (0,0)->(10,0)
        let v1 = LwVertex::from_coords(10.0, 0.0);
        poly.vertices = vec![v0, v1];
        poly.is_closed = false;
        doc.add_entity(EntityType::LwPolyline(poly)).unwrap();

        let (lines, _tris, _unsupported) = extract_geometry(&doc);
        // Duz cizgi olsaydi SADECE 2 nokta (1 segment) olurdu; bulge
        // tessellate edildigi icin COK DAHA FAZLA nokta olmali (16 segment = 32 nokta).
        assert_eq!(lines.len(), 32, "bulge'lu tek segment 16 alt-segmente (32 nokta) tessellate edilmeli");
    }
}
