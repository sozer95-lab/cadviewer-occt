# Çözüm Kalite — Malzeme Kütüphanesi + CAD Görüntüleyici

Tek bir Android uygulaması, açılışta iki bağımsız araca yönlendiren bir ana
menü sunar:

- **Malzeme Kütüphanesi** — malzeme arama, elle girilen kimyasal analizle
  eşleştirme, kendi malzemeni ekleme. Tamamen çevrimdışı, WebView tabanlı.
- **CAD Görüntüleyici** — STL/OBJ 3B model dosyalarını görüntüleme, orbit/zoom,
  mesafe/açı ölçümü. Native OpenGL ES 3.0 + JNI/C++ tabanlı.

**Tamamen çevrimdışı.** Uygulamanın hiçbir ağ izni yoktur.

---

## Malzeme Kütüphanesi

Malzeme adı, EN/DIN numarası, eski/atölye adı veya AISI karşılığı ile arama
yapın; sınıfa göre filtreleyin. Elinizdeki bir spektrometre analizinden
bildiğiniz element yüzdelerini girip veritabanındaki hangi kalitelerin uyduğunu
görün. Kütüphanede olmayan bir malzemeyi kendi kayıtlarınıza ekleyin (yalnızca
cihazda saklanır).

600 malzeme kayıtlı, ~208'i tam doğrulanmış kimyasal bileşim aralığı taşıyor.

> **Bu bir TEYİT değil, aday listesidir.** Malzeme kararı, sertifika ve
> akredite laboratuvar raporuyla verilir.

**Karşılaştırma:** Arama sonuçlarındaki "+" butonuyla en fazla 3 malzemeyi
karşılaştırmaya ekleyin; ekranın altında beliren "Karşılaştır" çubuğuyla
seçilenleri yan yana (numara, standart, AISI, yoğunluk ve tüm elementlerin
birleşimi) gösteren bir tabloya geçin. 14 gerçek tarayıcı testiyle
doğrulandı (limit kontrolü, ortak element gösterimi, temizleme dahil).

## CAD Görüntüleyici

**Arayüz tasarımı:** İlk sürümlerde bu ekran tamamen düz, programatik
Android bileşenleriyle (varsayılan gri butonlar, tek bir yatay satırda 11
buton, kaydırma sarmalayıcısı olmadan) inşa edilmişti — bu, gerçek bir
kullanılabilirlik sorunuydu (butonlar telefon ekranına sığmazdı). Şimdi
Malzeme Kütüphanesi'yle **birebir aynı renk paletiyle** (çelik mavisi
`#2E4A5E` başlık, meneviş amber `#C97B2E` vurgu, `#EEF1EF` zemin) yeniden
tasarlandı: kaydırılabilir, işlev grubuna göre renk kodlanmış "hap"
butonlar (Dosya/Görünüm/Ölçüm/Malzeme grupları), üç sütunlu bir bilgi
kartı (Ölçüm | Boyut | Ağırlık), ve stilize edilmiş bir malzeme seçici
diyaloğu.

**Desteklenen formatlar: STL (ASCII + binary), OBJ, STEP/IGES, ve DWG/DXF.**
Dosya açıldığında otomatik olarak 3B/2B görünüme yüklenir; parmakla döndürme
(orbit), Distance (2 nokta) ve Angle (3 nokta) ölçümü, geçmiş ölçümleri
silme/temizleme mevcuttur.

### DWG/DXF desteği — kapsam ve sınır

DWG/DXF, `dwg_bridge` (Rust, `acadrust` kütüphanesi üzerine ince bir FFI
katmanı — **MIT lisanslı**, GPL gibi bir kısıtlama getirmez) ile okunur.

**Render edilen varlıklar:**
- LINE, CIRCLE, ARC — çizgi segmentlerine (tessellate edilmiş) çevrilir
- LWPOLYLINE, POLYLINE3D — vertex zinciri, çizgi segmentleri olarak
- 3DFACE — gerçek üçgen/dörtgen yüzey verisi (ACIS gerektirmeyen, doğrudan 3D geometri)

**Render EDİLEMEYEN varlıklar:**
- **3DSOLID/BODY/REGION (ACIS/SAT tabanlı 3D katılar) — KISMİ destek:**
  Önce AutoCAD'in genelde bu varlıklarla birlikte **görüntüleme amaçlı hazır
  tel kafes (wireframe) verisi** sakladığı kontrol edilir — bu veri VARSA,
  katının **gerçek 3D şekli tel kafes olarak** (kenar çizgileri) gösterilir.
  Bu veri YOKSA (bazı DWG yazıcıları dahil etmez), tam ACIS/SAT B-rep
  ayrıştırması bu sürümde **YAPILMAZ** — varlık sayılır ve kullanıcıya
  bildirilir. Tam B-rep desteği (SAT verisinin OCCT'nin `TopoDS_Shape`'ine
  aktarılıp dolu yüzey render edilmesi) gelecekteki bir çalışma konusudur;
  `acadrust`'ın ACIS modülü bunun için gereken tüm veriyi (yüzey/eğri
  türleri ve parametreleri) sağlıyor, ama bu dönüştürücünün kendisi henüz
  yazılmadı.
- Ağırlık hesaplama DWG/DXF için **desteklenmiyor** (hacim kavramı, kapalı
  olmayan çizim verisi için genelde anlamsızdır)

Bu, karışık içerikli (2D çizim + 3D katı) DWG dosyalarında **2D/wireframe
kısmın görüneceği, 3D katı parçaların görünmeyeceği** anlamına gelir —
uygulama bunu açıkça bir bildirimle belirtir, sessizce eksik göstermez.

**Ağırlık hesaplama (Malzeme Kütüphanesi entegrasyonu):** "Malzeme" butonuna
basıp, malzeme kütüphanesindeki 600 malzemeden birini (arayarak) seçin —
seçilen malzemenin yoğunluğu kullanılarak, yüklü modelin ağırlığı otomatik
hesaplanır ve gösterilir.

- **STEP/IGES için hacim TAM DOĞRUdur** — gerçek BREP geometrisinden
  (`BRepGProp::VolumeProperties`) hesaplanır, tesselasyon yaklaşıklığı
  DEĞİLDİR.
- **STL/OBJ için hacim YAKLAŞIKtır** — üçgen ağından (diverjans teoremi ile)
  hesaplanır; ekranda "yaklaşık (mesh tabanlı)" notu gösterilir.
- Malzeme ve model bilgisi `app/src/main/assets/materials.json` üzerinden
  köprülenir — bu, malzeme kütüphanesinin 600 kaydından (ad, standart no,
  sınıf, yoğunluk) türetilmiş bir anlık görüntüdür. **Malzeme kütüphanesi
  veritabanı (`malzeme.js`) ileride değişirse, bu JSON dosyasının da
  yeniden üretilmesi gerekir** (Node ile `malzeme.js`'i import edip
  `yog` alanlarını dışa aktararak — bkz. proje geçmişindeki komut).

> **Ağırlık da bir TAHMİNdir, tartım değildir.** Hacim hesaplaması (özellikle
> STL/OBJ'de) ve malzeme yoğunluğu (kütüphanedeki tipik değer, gerçek
> sertifika değeri değil) yaklaşıklık içerir. Kritik kararlar için gerçek
> tartım kullanın.

**Işıklandırma:** Yüzeyler artık düz (flat) diffuse ışıklandırmayla
render ediliyor — her üçgenin normali (kenar vektörlerinin çapraz çarpımı)
hesaplanıp, kameraya sabit ("baş lambası") bir ışık yönüyle karıştırılıyor.
Bu, orbit yaparken ışığın her zaman bakış açınızdan geldiği anlamına gelir;
eğrisel/karmaşık parçalarda yüzey dönüşlerini ayırt etmeyi kolaylaştırır.
Normal hesaplama formülü host'ta gerçek testlerle doğrulandı (yön, birim
uzunluk, pozisyon aktarımı — 8/8 test).

**Kesit (section) görünümü:** "Kesit" butonuna basıp eksen (X/Y/Z) seçin ve
kaydırıcıyla düzlemi modelin içine doğru hareket ettirin — düzlemin bir
tarafındaki geometri gizlenir, iç yapı/et kalınlığı görülebilir. Hem ana
mesh (STL/OBJ/STEP/IGES) hem DWG tel kafes geometrisi kesilir; ölçüm
noktaları/işaretçileri BİLEREK kesilmez (kesip geçtiğinizde işaretlerin
aniden kaybolmaması için). Düzlem matematiği (merkez/yarıçapa göre
eksen+kaydırma oranından gerçek dünya konumu) host'ta gerçek bir
`Renderer3D` örneği üzerinden doğrulandı (merkez/yarıçap hesabı, eksen
seçimi, sınır kırpma, enable/disable — 9/9 test).

**Parça boyutu (X × Y × Z):** Model açıldığında ölçüm satırının altında
gerçek eksen-hizalı sınır kutusu boyutu gösterilir. `Renderer3D`'nin
gerçek min/max koordinat takibiyle hesaplanır; bilinen bir kutuyla (6/6
test) doğrulandı.

**Ölçü birimi (mm/inç):** "mm/in" butonuna basarak mesafe ölçümü ve parça
boyutu gösterimini milimetre/inç arasında değiştirin. Açı ölçümü
(derece) bu ayardan ETKİLENMEZ — birimsiz bir orandır. Dönüşüm C++
tarafında merkezi bir noktada uygulanır (hem ana ölçüm metni hem 3B
ekran üzerindeki etiket AYNI, tutarlı değeri gösterir).

**Tel kafes / dolu yüzey görünümü:** "Tel Kafes" butonuyla ana mesh'i
(STL/OBJ/STEP/IGES/3DFACE) dolu yüzey yerine sadece kenar çizgileriyle
görüntüleyin — iç geçişleri/yüzey sayısını incelemek için. DWG'nin kendi
çizgi geometrisi (LINE/ARC/vb.) bu ayardan etkilenmez, o zaten her zaman
çizgi olarak gösterilir. Kenar çıkarma mantığı host'ta gerçek bir
üçgenle (7/7 test) doğrulandı.

**LWPOLYLINE yay (bulge) desteği:** DWG/DXF'teki eğrisel polyline
kenarları artık düz çizgi değil, **gerçek yay** olarak tessellate
ediliyor. Bu, matematiksel olarak en riskli eklentilerden biriydi —
geliştirme sırasında kendi test beklentimde bir işaret hatası bulundu
(sezgisel "pozitif bulge = yukarı büker" varsayımı yanlıştı); bu,
tahmin edilmeden gerçek DXF standardı araştırılarak (pozitif bulge =
yürüyüş yönüne göre SAĞA büker) doğrulandı ve düzeltildi. Yarı çember,
çeyrek çember, negatif yön ve entity-seviyesi entegrasyon dahil 6/6
gerçek Rust testiyle doğrulandı.

### STEP/IGES desteği — OCCT durumu

**Bu sürümde gerçek OCCT (OpenCASCADE Technology) Android ARM64 derlemesi
entegre edilmiştir** (`app/src/main/cpp/third_party/occt/` altında, 15
kütüphane + ~8400 header dosyası). `CADVIEWER_HAS_OCCT=1` bayrağı
`app/build.gradle.kts`'de açıktır.

Bu derleme, projeye eklenen `.github/workflows/build-occt-android.yml`
GitHub Actions iş akışıyla, OCCT V7_8_1 kaynağından, gerçek Android NDK
kullanılarak üretildi (GitHub'ın kendi sunucularında — bir AI sandbox
ortamında bu derleme yapılamaz, bkz. bir alt başlık).

**Yapılan doğrulamalar** (gerçek cihaz/emülatör olmadan, host makinede):
- `OCCTBridge.cpp`, gerçek OCCT header'larıyla host'ta hatasız derlendi
  (`-DCADVIEWER_HAS_OCCT=1 -I third_party/occt/include -fsyntax-only`)
- Tüm proje (JNI köprüsü, renderer, picking, measurement, kernel adapter,
  mesh reader) `CADVIEWER_HAS_OCCT=1` ile birlikte host'ta sıfır hatayla
  derlendi
- `OCCTBridge.o`'nun ihtiyaç duyduğu 89 sembolün **tamamının**, `.so`
  dosyalarında gerçekten tanımlı olduğu `nm` ile sembol düzeyinde
  doğrulandı — bu süreçte **iki eksik kütüphane bulundu ve eklendi**:
  `TKLCAF` ve `TKXCAF` (XDE/Application Framework sınıfları için
  gerekliydi, ilk listede yoktu — projenin orijinal geliştiricisinin de
  gözden kaçırdığı bir eksiklikti)

**Doğrulanamayan kısım** (gerçek cihaz gerektirir): STEP/IGES dosyası
açmanın uçtan uca çalışması, gerçek bir geometri üzerinde tessellation
performansı, ve APK'nın gerçek boyutu/kurulumu. `.so` dosyaları ARM64
(aarch64) formatında doğrulandı ama x86_64 host makinede gerçekten
çalıştırılıp test edilemedi.

### OCCT'yi yeniden derlemek isterseniz

Yukarıdaki iş akışı depoda kalıcı olarak durur; farklı bir OCCT sürümü
veya Android API seviyesi için tekrar çalıştırabilirsiniz:

1. GitHub'da depo → **Actions** → **"OCCT Android ARM64 derlemesi"**
2. **Run workflow**, istediğiniz `occt_ref` (örn. `V7_9_0`) ve
   `android_api_level` değerlerini girin
3. ~25-30 dakika sonra **Artifacts** bölümünden `occt-android-arm64.zip`'i
   indirin
4. `arm64-v8a/` ve `include/` klasörlerinin içeriğini
   `app/src/main/cpp/third_party/occt/` altındaki aynı isimli klasörlere
   kopyalayıp üzerine yazın

**OCCT olmadan** (bayrak kapalıyken) uygulama içinde CAD Görüntüleyici
ekranı, hangi formatların çalıştığını açıkça gösterir; sahte/placeholder
bir 3B model göstermez.

---

## Sistem gereksinimleri

**Java/JDK gerekmiyor — Android Studio'yu kurman yeterli.** Android Studio,
uyumlu bir JDK'yı (JBR, 17+) kendi içinde getirir. **Android NDK ve CMake**
de Android Studio'nun SDK Manager'ından kurulmalıdır (native C++ kod
içerdiği için) — Android Studio ilk açılışta bunu otomatik önerir.

Bu projede **Gradle sarmalayıcısı (wrapper) dahildir**. Android Studio
projeyi açtığında doğru Gradle sürümünü (8.9) kendisi indirir.
Sürümler: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9,
compileSdk/targetSdk 35, minSdk 26, C++17.

**İlk derlemede internet gerekir** (Gradle, NDK ve bağımlılıkları indirmek
için); sonraki derlemeler önbellekten çalışır.

## Derleme

`CadViewer/` klasörünü Android Studio ile açın, sonra:

    Build > Build Bundle(s) / APK(s) > Build APK(s)

APK `app/build/outputs/apk/debug/` içinde çıkar.

Malzeme Kütüphanesi'ni Android Studio olmadan, sadece tarayıcıda önizlemek
isterseniz:

    cd app/src/main/assets
    python3 -m http.server 8080

sonra `http://localhost:8080` adresine girin. (CAD Görüntüleyici native
kod içerdiği için bu şekilde önizlenemez, gerçek bir derleme/cihaz gerekir.)

---

## Teknik yapı

```
app/src/main/
├── java/com/serdar/cadviewer/     ← Ana menü + Malzeme Kütüphanesi
│   ├── HomeActivity.kt              (LAUNCHER, iki alt uygulamaya geçiş)
│   └── MaterialLibraryActivity.kt   (WebView + WebViewAssetLoader)
├── java/com/cadviewer/            ← CAD Görüntüleyici (native)
│   ├── CadViewerActivity.kt         (GLSurfaceView + ölçüm UI)
│   ├── CadViewerSurface.kt          (dokunma/orbit/pick olaylarını iletir)
│   ├── CadNative.kt                 (JNI external fun bildirimleri)
│   └── CadFilePicker.kt             (STEP/IGES/STL/OBJ dosya seçici)
├── assets/                        ← Malzeme Kütüphanesi web uygulaması
│   ├── malzeme.js                   (600 malzemelik veritabanı)
│   ├── eslesme.js                   (kimyasal analiz eşleştirme mantığı)
│   ├── app.js / index.html
└── cpp/                           ← CAD Görüntüleyici native kodu
    ├── jni/CadNative.cpp             (JNI köprüsü)
    ├── renderer/Renderer3D.cpp       (OpenGL ES 3.0 render + kamera)
    ├── geometry/Picking.cpp          (ray-üçgen kesişimi)
    ├── measurement/Measurement.cpp   (Distance/Angle hesaplama + geçmiş)
    ├── kernel/mesh_reader/           (STL/OBJ okuyucu — OCCT gerektirmez)
    └── kernel/occt_bridge/           (STEP/IGES — gerçek OCCT bekliyor)
```

İki alt uygulama (Malzeme Kütüphanesi ve CAD Görüntüleyici) **bilerek**
birbirinden bağımsız `Activity`'ler olarak tutulmuştur: biri WebView tabanlı
dikey bir arayüz, diğeri tam ekran, yatay kilitli bir OpenGL yüzeyi. İkisini
tek bir ekranda birleştirmek gereksiz karmaşıklık ve kararlılık riski katardı;
`HomeActivity` sadece aralarında geçiş yapar.

### Bu birleştirmede düzeltilen gerçek hatalar

Orijinal CAD Görüntüleyici paketinde (CADViewerCore) tespit edilip
düzeltilen sorunlar:

- **Derleme hatası:** `OCCTBridge.h` içinde `ModelUnit` türü hiç
  tanımlanmadan kullanılıyordu — bu, OCCT olsun olmasın projeyi
  derlenemez hale getirirdi. `KernelTypes.h`'ye eklendi.
- **Mantık hatası:** Dosya seçildiğinde oluşturulan geçici dosya hiç
  uzantı taşımıyordu, bu yüzden format algılama (STEP/IGES/STL/OBJ ayrımı)
  hiçbir zaman doğru çalışmıyordu. Artık gerçek dosya adından uzantı
  çıkarılıp geçici dosyaya ekleniyor.
- **Eksik JNI bildirimi:** `nativeKernelAvailable()` C++ tarafında
  tanımlıydı ama Kotlin tarafında `external fun` olarak bildirilmemişti.
- **19 dosyalık kullanılmayan/terk edilmiş kod** (CameraRayBuilder, Camera,
  PickingPipeline, MeshPicker, RayTriangleIntersection, MeasurementLabel,
  MeshGpuCache, SelectionRenderer, MeasurementBridge, CadContext) kaldırıldı.
  Bunlar `CMakeLists.txt`'nin derleme listesine hiç girmemiş, geliştirme
  sürecinin ara aşamalarından kalan prototiplerdi; gerçek işlevsellik zaten
  `Renderer3D`, `Picking`, `Measurement` ve `CadNative.cpp` içinde tam ve
  doğru şekilde yazılıydı.
- **Eksik Gradle wrapper, kaynak dosyalar (`strings.xml`, `colors.xml`,
  launcher icon), sürüm numarası tutarsızlığı** tamamlandı/düzeltildi.
- **STL/OBJ desteği eklendi** (`MeshFileReader.cpp`) — OCCT gerektirmeyen,
  bugün çalışan bir 3B görüntüleme yolu sağlamak için.
- **Eksik OCCT kütüphane bağımlılığı:** Gerçek OCCT header'larıyla yapılan
  sembol düzeyinde doğrulamada, `OCCTBridge.cpp`'nin kullandığı
  `TKLCAF`/`TKXCAF` (XDE/Application Framework) kütüphanelerinin
  `CMakeLists.txt`'nin bağlama listesinde hiç olmadığı bulundu — bu,
  cihazda "cannot locate symbol" hatasına yol açardı. Eklendi.
- **Eksik jniLibs yapılandırması:** CMake'in OCCT `.so` dosyalarını
  "IMPORTED" olarak tanımlaması tek başına onları APK'ya koymuyordu;
  `app/build.gradle.kts`'e `jniLibs.srcDirs(...)` eklendi.

### Doğrulama yöntemi ve sınırları

**Bu bölümdeki bulgular, "başka eksik var mı" sorusuyla yapılan kapsamlı bir
son denetimde ortaya çıktı — burada dürüstçe paylaşılıyor çünkü bazıları
önceki teslimlerin çalışmayacağı anlamına geliyordu:**

- **En kritik bulgu:** `CadViewerSurface.kt`'de fazladan bir kapanış
  parantezi (`} }` yerine `}`) vardı — bu, projenin **hiçbir zaman
  derlenemeyeceği** anlamına geliyordu. Bu, önceki tüm teslimlerde
  (OCCT, ağırlık hesaplama, DWG sürümleri dahil) vardı ve fark edilmemişti,
  çünkü Kotlin dosyaları o zamana kadar sadece parantez sayılarak
  (yetersiz bir yöntem) kontrol ediliyordu. Bu denetimde gerçek `kotlinc`
  derleyicisi kurulup çalıştırılarak bulundu ve düzeltildi; artık 6/6
  Kotlin dosyası sıfır sözdizimi hatasıyla derleniyor.
- **DWG'de ölçüm hiç çalışmıyordu:** `nativePick()` sadece üçgen mesh'e
  bakıyordu, DWG geometrisi (çizgi tabanlı) ayrı bir yapıda tutulduğu için
  kullanıcı DWG açıp ekrana dokunsa bile sessizce hiçbir şey olmuyordu.
  Ray-segment picking eklenip gerçek testlerle (4/4) doğrulandı.
- **Yanıltıcı ağırlık mesajı:** DWG açıldığında "model yüklü değil"
  gösteriliyordu (oysa model yüklüydü, sadece o format için ağırlık
  hesaplanamıyordu). Düzeltildi.
- **`.a`/`.so` dosyaları eksikken build tamamen başarısız oluyordu:**
  Hem DWG bridge (`CMakeLists.txt`) hem OCCT (`app/build.gradle.kts`'nin
  koşulsuz geçirdiği bayrak) için, dosyalar yoksa proje **linker hatasıyla
  çökerdi**. Artık her ikisi de dosyanın gerçekten var olup olmadığını
  `CMake`'in `EXISTS` kontrolüyle sınıyor; yoksa ilgili özellik sessizce/
  uyarıyla kapanıyor, build başarısız olmuyor. Bu, hem `CADVIEWER_HAS_OCCT`
  hem `CADVIEWER_HAS_DWG` için gerçek bir CMake configure+generate
  çalıştırmasıyla (host'ta, dosyalar geçici olarak var/yok yapılarak) her
  iki yönde de doğrulandı.

Bu ortamda gerçek bir Android cihaz/emülatör veya NDK toolchain
bulunmadığından, C++ kodu şu şekilde doğrulandı: Android'e özgü başlıkları
(`jni.h`, `GLES3/gl3.h`, `android/log.h`) taklit eden minimal stub'lar
yazılıp **tüm CAD Görüntüleyici C++ kodu (JNI köprüsü, renderer, picking,
measurement, kernel adapter, mesh reader, DWG bridge dahil) host makinede
gerçekten derlenip paylaşımlı kütüphane olarak bağlandı** — sıfır hata,
OCCT+DWG'nin tüm kombinasyonlarında (ikisi de var, ikisi de yok, biri var
biri yok). Kotlin ve C++ arasındaki 28 JNI fonksiyonunun tamamının isim ve
tip olarak birebir eşleştiği ayrıca doğrulandı. `MeshFileReader` (STL/OBJ
ayrıştırıcı), gerçek test dosyalarıyla 16/16 testte doğrulandı.

**OCCT entegrasyonu için ek doğrulama** (GitHub Actions ile gerçek OCCT
Android ARM64 derlemesi elde edildikten sonra): `OCCTBridge.cpp`, gerçek
OCCT header'larıyla host'ta sıfır hatayla derlendi; projenin ihtiyaç
duyduğu 89 sembolün tamamının, bağlanan 15 kütüphanede gerçekten tanımlı
olduğu `nm` ile sembol düzeyinde doğrulandı; `.so` dosyalarının gerçek
ARM64 (aarch64 ELF) formatında olduğu `file` komutuyla doğrulandı.

**Ağırlık hesaplama için ek doğrulama:** Mesh tabanlı hacim formülü
(diverjans teoremi), bilinen boyutlu bir küple (10×10×10 mm → tam 1000
mm³) host'ta test edildi, sıfır hata payı ile doğru sonuç verdi. Uçtan uca
zincir (STL dosyası okuma → hacim hesaplama → yoğunlukla ağırlık) 100×100×100
mm, 7.85 g/cm³ yoğunluklu bir çelik küple test edildi: beklenen 7.8500 kg,
elde edilen 7.8500 kg. `BRepGProp::VolumeProperties`'in yoğunluk
belirtilmediğinde gerçekten hacim (kütle değil) döndürdüğü, resmi OCCT
dokümantasyonundan doğrulandı (tahmin edilmedi). Yeni eklenen 5 JNI
fonksiyonu (`nativeSetMaterialDensity`, `nativeMaterialDensity`,
`nativeVolumeCm3`, `nativeWeightKg`, `nativeVolumeIsExact`) dahil, Kotlin
↔ C++ arasındaki 26 fonksiyonun tamamı isim/tip olarak yeniden doğrulandı.

**Doğrulanamayan kısım:** Gerçek bir cihazda OpenGL render çıktısının görsel
doğruluğu, dokunma/orbit hissiyatı, STEP/IGES dosyası açmanın uçtan uca
çalışması, ve gerçek bir STEP dosyasında `BRepGProp::VolumeProperties`'in
pratikte doğru/tutarlı sonuç vermesi (host makinede ARM64 .so dosyaları
çalıştırılamaz, sadece derleme/sembol/matematik doğrulaması yapılabilir)
— bunlar için gerçek bir Android cihaz/emülatörde derleme ve manuel test
gereklidir.

## Lisans

Çekirdek dosyalarda üçüncü taraf bir kütüphane/lisans yükümlülüğü yoktur.
OCCT'yi kendiniz eklerseniz, OCCT **LGPL-2.1 (istisnalı)** lisansı altındadır;
kendi kullanımınız için yükümlülük doğurmaz, dağıtım öncesi lisans şartlarını
gözden geçirin.
