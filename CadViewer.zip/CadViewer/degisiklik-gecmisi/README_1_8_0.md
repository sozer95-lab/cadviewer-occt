# CADViewerCore 1.8.0

- Completed measurement labels now have a true 3D anchor derived from the selected measurement points.
- Renderer projects the anchor into current screen coordinates using the active camera transform.
- Android can query label text and its live screen position, allowing the UI overlay to follow Orbit, Zoom, Fit and Home movements.
- Labels are hidden when the anchor is outside the camera frustum or behind the camera.
