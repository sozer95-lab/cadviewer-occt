# CADViewerCore 0.9.0
Added real CPU mesh-picking baseline:
Touch -> Camera ray -> Ray/Triangle intersection -> Nearest hit -> faceId + world point.
The current implementation uses a linear scan for correctness. BVH acceleration is the next step.
No fake OCCT binaries are bundled.
