# CADViewerCore 1.7.0

- Measurement result label state added.
- Completed measurements now publish a stable text value for the Android UI.
- Starting a new pick after a completed measurement automatically restarts the same measurement mode.
- Existing measurement points and line overlay remain synchronized with the active measurement cycle.
