# CADViewerCore 1.3.0

## Tamamlanan ana entegrasyon
- Gerçek ekran koordinatı artık aktif kamera yönüne göre 3D ray'e dönüştürülür.
- Ray, yüklenmiş gerçek MeshData üçgenleriyle CPU tarafında kesiştirilir.
- En yakın triangle hit seçilir.
- Seçilen gerçek dünya noktası doğrudan MeasurementManager'a aktarılır.
- Distance ölçümünde iki başarılı dokunuş sonrası mesafe sonucu `model` birimiyle alınabilir.

## Sonraki adım
Ölçüm sonucunun Android arayüzünde anlık gösterilmesi ve iki seçili noktanın/ölçüm çizgisinin OpenGL üzerinde çizilmesi.
