# CADViewerCore 1.9.0

## Added
- Android overlay measurement label above the OpenGL viewer.
- Native 3D measurement anchor is projected every frame and used to reposition the label.
- Label is hidden when no completed measurement exists or the anchor is not visible.
- Distance and angle labels update while Orbit, Zoom, Fit and Home change the camera.

## Preserved
- CAD mesh rendering
- Real ray-triangle picking
- Distance and angle measurement
- Measurement markers and lines
- Orbit / Fit / Home
