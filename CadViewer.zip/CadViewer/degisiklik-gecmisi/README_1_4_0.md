# CADViewerCore 1.4.0

- Picked measurement points are rendered as visible OpenGL ES markers.
- Two selected points are connected by a measurement line.
- Measurement value is pushed to the Android UI after each successful pick.
- Fit/Home/Orbit and existing CPU ray-triangle picking remain intact.
