# CADViewerCore 0.4.0

This milestone connects the Android Open-document flow to the native kernel boundary.

## Added
- Android CAD file picker for STEP/STP/IGES/IGS.
- URI -> private cache file copy before native import.
- `KernelAdapter` / `OCCTKernelAdapter` boundary.
- Format validation.
- Explicit failure until the real OCCT Android ARM64 libraries are supplied.
- CMake includes the adapter source.

## Important
This package does **not** contain fake OCCT `.so` libraries. `nativeOpen()` deliberately returns an explicit error until the real OCCT ARM64 build is placed under `third_party/occt` and the reader implementation is enabled.
