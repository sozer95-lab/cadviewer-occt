# CADViewerCore 2.0.0

- Completed measurements are retained in native history.
- Distance and angle results are preserved while a new measurement cycle starts.
- Full clear still removes active and historical measurements.
- Foundation added for rendering multiple persistent measurement annotations.
