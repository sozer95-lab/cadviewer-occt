# CADViewerCore 1.5.0

Measurement workflow hardening:
- Measurement point state is now owned by MeasurementManager.
- Clear resets both logical and visual measurement state.
- Distance and Angle modes are exposed in Android UI.
- Picked points are rendered directly from the authoritative measurement state.
- Distance uses 2 points; Angle uses 3 points and returns degrees.
