# CADViewerCore 1.0.0
- Removed the fake cube render path.
- Kernel tessellation output now uploads directly to the OpenGL ES renderer.
- Imported CAD geometry is the render source once a real OCCT kernel is linked.
- Existing picking baseline remains ready for the next integration step.

Next core milestone: connect mesh picking to touch coordinates and then add camera framing from mesh bounds.
