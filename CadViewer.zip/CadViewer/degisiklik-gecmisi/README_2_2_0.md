# CADViewerCore 2.2.0

## Added
- Completed measurement history can now be edited.
- Native API deletes the most recently completed measurement.
- Renderer history is synchronized immediately after deletion.
- Android UI includes a Delete Last action.
- Active measurement remains independent from completed history.
- Clear still removes active and completed measurements.

## Core flow
Open CAD -> Fit/Home/Orbit -> Distance or Angle -> Pick points -> Completed measurement remains visible -> Delete Last or Clear.
