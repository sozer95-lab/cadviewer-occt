# CADViewerCore 1.1.0

Bu sürüm gerçek model sınırlarına göre kamera kontrolünü ekler:
- Mesh bounding box hesaplama
- Otomatik Fit
- Home görünümü
- Orbit (yaw/pitch)
- Zoom
- Model merkezine göre kamera dönüşü

Sonraki çekirdek aşaması: dokunmatik picking sonucunu Android olaylarıyla bağlamak ve ölçüm noktalarını gerçek mesh yüzeyinden seçmek.
