# CADViewerCore 0.5.0

This increment makes the OCCT integration build-ready without shipping fake
libraries. The native adapter has a real compile switch and an explicit slot
for the OCCT ARM64-v8a runtime.

Current state:
- Android CAD file picker: STEP/STP/IGES/IGS
- Native kernel adapter boundary
- OCCT build switch
- ARM64 library slot and CMake import point
- Existing renderer, camera, picking and measurement core retained

Not claimed as complete:
- No fake OCCT .so files
- STEP/IGES import remains disabled until the real OCCT ARM64 build is placed
  in third_party/occt
- Exact B-Rep measurement is not enabled until that runtime is present
