# CADViewerCore 1.6.0

Measurement workflow completion:
- Completed Distance/Angle measurements remain visible until the next successful pick.
- The next pick automatically starts a fresh measurement in the active mode.
- UI now shows point progress (1/2, 2/3, etc.) and clearly indicates when a new measurement can begin.
- Measurement mode stays active across repeated measurements; Clear is no longer required between measurements.
- Existing real mesh picking, Fit/Home, Orbit, overlay markers and lines are preserved.
