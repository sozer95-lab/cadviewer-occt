# CADViewerCore 0.8.0

3D interaction integration layer.

Added:
- CameraRayBuilder boundary for screen-space to world-ray conversion.
- PickingPipeline now tracks viewport dimensions.
- SelectionRenderer state for selected face highlighting.
- Existing MeasurementBridge and MeshGpuCache remain.
- No fake OCCT binaries.

Next:
- Feed actual Camera inverse view/projection matrices.
- Connect ray to mesh/BVH intersection.
- Send PickHit.faceId into SelectionRenderer and MeasurementBridge.
