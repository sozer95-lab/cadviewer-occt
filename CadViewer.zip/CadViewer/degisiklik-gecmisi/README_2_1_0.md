# CADViewerCore 2.1.0

## Çoklu ölçüm görünümü
- Tamamlanan Distance ve Angle ölçümleri renderer tarafına senkronize edilir.
- Geçmişteki ölçümlerin noktaları ve çizgileri model üzerinde aynı anda korunur.
- Aktif ölçüm ayrıca gösterilmeye devam eder.
- Clear işlemi aktif ve geçmiş ölçümlerin görsel katmanını birlikte temizler.

Bu sürüm, 2.0.0'daki ölçüm geçmişi verisini ilk kez doğrudan 3D görünümde kullanır.
