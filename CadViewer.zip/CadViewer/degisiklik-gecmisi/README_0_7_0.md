# CADViewerCore 0.7.0

0.7.0 advances the 0.6.0 native core toward a usable 3D viewport.

Added:
- PickingPipeline boundary for screen -> 3D hit conversion.
- MeasurementBridge for Distance/Angle/Radius/Diameter/Area/Volume point/entity state.
- MeshGpuCache boundary preserving faceId per GPU vertex.
- No fake OCCT binaries.
- OCCT remains an optional real native dependency.

Target runtime chain:

Android touch
-> PickingPipeline
-> faceId/world point
-> MeasurementBridge
-> OCCT exact measurement

OCCT binary integration is still required for actual STEP/IGES execution.
