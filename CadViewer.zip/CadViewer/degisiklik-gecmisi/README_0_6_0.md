# CADViewerCore 0.6.0

## Bu sürüm
0.5.0 üzerine gerçek OCCT çağrı zincirinin native bridge katmanı eklendi.

### Gerçekleşen zincir
Android URI/native path → JNI `nativeOpen()` → `OCCTKernelAdapter` → `OCCTBridge` → STEPCAFControl/IGESCAFControl → XCAF document → TopoDS shape → `BRepMesh_IncrementalMesh` → `MeshData`.

### OCCT derleme davranışı
- Varsayılan: `CADVIEWER_HAS_OCCT=OFF`; uygulama sahte kernel kullanmaz.
- Gerçek OCCT ARM64 başlıkları ve `.so` dosyaları `app/src/main/cpp/third_party/occt/` altına konduğunda CMake ile etkinleştirilir.
- Bu pakete sahte `.so` eklenmemiştir.

### Yeni dosyalar
- `kernel/occt_bridge/OCCTBridge.h`
- `kernel/occt_bridge/OCCTBridge.cpp`

### Güncellenenler
- `KernelAdapter.h`: tessellation sözleşmesi
- `OCCTKernelAdapter.*`: gerçek bridge çağrısı
- `jni/CadNative.cpp`: nativeOpen ve kernel availability
- `CMakeLists.txt`: OCCTBridge kaynak dosyası

## Bilinçli sınır
Mesh artık OCCT'den gerçek `MeshData` yapısına çevriliyor; GPU upload/Renderer'a gerçek model mesh bağlama ve face-ID picking bir sonraki aşamadır. OCCT runtime olmadan import başarıyla sonuçlandırılmaz.
