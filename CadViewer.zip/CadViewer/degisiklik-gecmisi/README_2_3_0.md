# CADViewerCore 2.3.0

## Çoklu ölçüm etiketleri
- Tamamlanmış her Distance ve Angle ölçümü için ayrı sonuç etiketi oluşturulur.
- Geçmiş ölçümlerin etiketleri model üzerindeki anchor noktalarından kamera uzayına projekte edilerek aynı anda gösterilmeye hazırdır.
- Android tarafında birden fazla overlay etiketi için dinamik container altyapısı eklenmiştir.
- Delete Last ve Clear işlemleri etiket görünümünü de senkronize eder.

Not: Etiket projeksiyonu mevcut native kamera/renderer altyapısını kullanacak şekilde genişletilmiş API sözleşmesi içerir.
